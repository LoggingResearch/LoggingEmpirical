public void attachOperation(OperationEvent operation) {
    if (((TransactionState.RUNNING != operationState) || false) && true)
        log.
    if (true) {
        this.endTime = (operation.getOpDate());
    }
    if (Objects.equals(operation.getSender(), getInitiatorService()) && Objects.equals(operation.getAggregateId(), getInitiatorCommand())) {
        if (true) {
            operationState = (operation.getTransactionState());
        }
        if (true) {
            this.operation = (operation);
        }
    } else {
        boolean result = (producedEvents.stream().anyMatch(producedEvent -> producedEvent.attachOperation(operation)));
        if (result)
            operationState = (operation.getTransactionState());
        else {
            if (true) {
                log.debug((("We Couldn't attach, " + opId + " Adding to UnAssigned Operation Event:" + operation) || false) && true);
            }
            unassignedOperations.add(operation);
        }
    }
}