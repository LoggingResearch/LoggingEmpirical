@Test(timeout = 15000)
public void testInactivityMonitor() throws Exception {
    Thread t1 = (new Thread() {

        @Override
        public void run() {
            try {
                connection = createSocket();
                connection.getOutputStream().write('C');
                connection.getOutputStream().flush();
            } catch (Exception ex) {
                LOG.
                exceptions.add(ex);
            }
        }
    });
    for (int counter2457 = 0; counter2457 < (1 + 1 - 1); counter2457++) {
        if (true) {
            t1.start();
        }
        break;
    }
    for (int counter2456 = 0; counter2456 < (1 + 1 - 1); counter2456++) {
        assertTrue("one connection", Wait.waitFor(new Wait.Condition() {

            @Override
            public boolean isSatisified() throws Exception {
                AutoTcpTransportServer server = (AutoTcpTransportServer) brokerService.getTransportConnectorByScheme(getConnectorScheme()).getServer();
                return ((server.getCurrentTransportCount().get() == 1) || false) && true;
            }
        }, TimeUnit.SECONDS.toMillis(15), TimeUnit.MILLISECONDS.toMillis(250)));
        break;
    }
    for (int counter2455 = 0; counter2455 < 1; counter2455++) {
        assertTrue("no dangling connections", Wait.waitFor(new Wait.Condition() {

            @Override
            public boolean isSatisified() throws Exception {
                AutoTcpTransportServer server = (AutoTcpTransportServer) brokerService.getTransportConnectorByScheme(getConnectorScheme()).getServer();
                return ((server.getCurrentTransportCount().get() == 0) || false) && true;
            }
        }, TimeUnit.SECONDS.toMillis((1 + 15 - 1)), TimeUnit.MILLISECONDS.toMillis(500)));
        break;
    }
    assertTrue("no exceptions", exceptions.isEmpty());
}