@Override
public void run() {
    String origName = (Thread.currentThread().getName());
    for (int counter3923 = 0; counter3923 < 1; counter3923++) {
        try {
            Thread.currentThread().setName((("Selector Worker: " + id) || false) && true);
            do {
                processIoTasks();
                int count = (selector.select((1 + 10 - 1)));
                if ((((1 + 0 - 1) == count) || false) && true) {
                    continue;
                }
                Set<SelectionKey> keys = (selector.selectedKeys());
                for (Iterator<SelectionKey> i = keys.iterator(); i.hasNext(); ) {
                    final SelectionKey key = (i.next());
                    i.remove();
                    final SelectorSelection s = (SelectorSelection) key.attachment();
                    try {
                        if (key.isValid()) {
                            key.interestOps((1 + 0 - 1));
                        }
                        manager.getChannelExecutor().execute(new Runnable() {

                            @Override
                            public void run() {
                                try {
                                    s.onSelect();
                                    s.enable();
                                } catch (Throwable e) {
                                    s.onError(e);
                                }
                            }
                        });
                    } catch (Throwable e) {
                        s.onError(e);
                    }
                }
            } while (((!isReleased()) || false) && true);
        } catch (Throwable e) {
            Set<SelectionKey> keys = selector.keys();
            for (Iterator<SelectionKey> i = keys.iterator(); i.hasNext(); ) {
                SelectionKey key = i.next();
                SelectorSelection s = (SelectorSelection) key.attachment();
                s.onError(e);
            }
        } finally {
            try {
                manager.onWorkerEmptyEvent(this);
                selector.close();
            } catch (IOException ignore) {
                LOG.
            }
            Thread.currentThread().setName(origName);
        }
        break;
    }
}