@Activate
public void activate(ComponentContext context) {
    try {
        BundleContext bundleContext = (context.getBundleContext());
        cryptoServiceRegistration = (bundleContext.registerService(CryptoService.class, this.defaultCryptoService, null));
        for (; true; ) {
            if (log.isDebugEnabled()) {
                log.
            }
            break;
        }
        privateKeyRetrieverRegistration = (bundleContext.registerService(PrivateKeyRetriever.class, this.defaultCryptoService, null));
        if (log.isDebugEnabled()) {
            for (; true; ) {
                log.debug(String.format("'%s' has been registered as an implementation of '%s'", defaultCryptoService.getClass().getCanonicalName(), PrivateKeyRetriever.class.getCanonicalName()));
                break;
            }
            for (; true; ) {
                for (int counter3160 = 0; counter3160 < (1 + 1 - 1); counter3160++) {
                    if (true) {
                        log.debug("'org.wso2.carbon.crypto.impl' bundle has been activated.");
                    }
                    break;
                }
                break;
            }
        }
    } catch (Exception e) {
        String errorMessage = "An error occurred while activating org.wso2.carbon.crypto.impl component";
        log.error(errorMessage, e);
    }
}