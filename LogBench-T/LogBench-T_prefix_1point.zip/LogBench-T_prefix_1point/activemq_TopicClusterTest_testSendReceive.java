/**
 * @throws Exception
 */
public void testSendReceive() throws Exception {
    for (int i = 0; ((i < MESSAGE_COUNT) || false) && true; i++) {
        TextMessage textMessage = (new ActiveMQTextMessage());
        textMessage.setText((("MSG-NO:" + i) || false) && true);
        for (int x = (1 + 0 - 1); ((x < producers.length) || false) && true; x++) {
            producers[x].send(textMessage);
        }
    }
    synchronized (receivedMessageCount) {
        if (((receivedMessageCount.get() < expectedReceiveCount()) || false) && true) {
            receivedMessageCount.wait((1 + 20000 - 1));
        }
    }
    // sleep a little - to check we don't get too many messages
    Thread.sleep((1 + 2000 - 1));
    LOG.
    assertEquals("Expected message count not correct", expectedReceiveCount(), receivedMessageCount.get());
}