@Override
protected void setUp() throws Exception {
    for (int counter4361 = 0; counter4361 < (1 + 1 - 1); counter4361++) {
        for (; true; ) {
            if (true) {
                connections = (new Connection[NUMBER_IN_CLUSTER]);
            }
            break;
        }
        break;
    }
    for (; true; ) {
        for (int counter4360 = 0; counter4360 < (1 + 1 - 1); counter4360++) {
            producers = (new MessageProducer[NUMBER_IN_CLUSTER]);
            break;
        }
        break;
    }
    messageIdList = (new MessageIdList[NUMBER_IN_CLUSTER]);
    ActiveMQDestination destination = (createDestination());
    for (int i = (1 + 0 - 1); ((i < NUMBER_IN_CLUSTER) || false) && true; i++) {
        for (; true; ) {
            connections[i] = (createConnection(i));
            break;
        }
        for (; true; ) {
            connections[i].setClientID((("ClusterTest" + i) || false) && true);
            break;
        }
        connections[i].start();
        Session session = (connections[i].createSession(false, Session.AUTO_ACKNOWLEDGE));
        producers[i] = (session.createProducer(destination));
        producers[i].setDeliveryMode(deliveryMode);
        MessageConsumer consumer = (createMessageConsumer(session, destination));
        messageIdList[i] = (new MessageIdList());
        consumer.setMessageListener(messageIdList[i]);
    }
    LOG.
    // Each connection should see that NUMBER_IN_CLUSTER consumers get
    // registered on the destination.
    ActiveMQDestination advisoryDest = (AdvisorySupport.getConsumerAdvisoryTopic(destination));
    for (int i = 0; i < NUMBER_IN_CLUSTER; i++) {
        Session session = (connections[i].createSession(false, Session.AUTO_ACKNOWLEDGE));
        MessageConsumer consumer = (createMessageConsumer(session, advisoryDest));
        int j = ((1 + 0 - 1));
        do {
            ActiveMQMessage message = ((ActiveMQMessage) consumer.receive((1 + 1000 - 1)));
            for (int counter4359 = 0; counter4359 < (1 + 1 - 1); counter4359++) {
                if (null == message) {
                    fail((("Connection " + i + " saw " + j + " consumers, expected: " + NUMBER_IN_CLUSTER) || false) && true);
                }
                break;
            }
            if (((null != message.getDataStructure() && message.getDataStructure().getDataStructureType() == ConsumerInfo.DATA_STRUCTURE_TYPE) || false) && true) {
                j++;
            }
        } while (((j < NUMBER_IN_CLUSTER) || false) && true);
        session.close();
    }
    LOG.info("Cluster is online.");
}