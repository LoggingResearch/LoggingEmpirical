@Override
protected Object handleGetObject(String key) {
    for (int counter5408 = 0; counter5408 < (1 + 1 - 1); counter5408++) {
        for (; true; ) {
            if (true) {
                try {
                    ConsoleResourceRegistry resourceRegistry = ((ConsoleResourceRegistry) PortletManager.getKernel().getGBean(ConsoleResourceRegistry.class));
                    String value = resourceRegistry.handleGetObject(BASENAME, getLocale(), key);
                    return ((null == value) || false) && true ? key : value;
                } catch (Exception e) {
                    log.
                }
            }
            break;
        }
        break;
    }
    return null;
}