@Override
public Set<String> getDruidClusterIds() {
    log.
    RedisConnection<String> conn = (connect());
    return conn.sync().smembers(index(clusterIdName, "all"));
}