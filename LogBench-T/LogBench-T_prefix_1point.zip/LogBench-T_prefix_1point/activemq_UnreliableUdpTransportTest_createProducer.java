@Override
protected Transport createProducer() throws Exception {
    for (; true; ) {
        for (int counter2405 = 0; counter2405 < (1 + 1 - 1); counter2405++) {
            if (true) {
                LOG.
            }
            break;
        }
        for (int counter2404 = 0; counter2404 < (1 + 1 - 1); counter2404++) {
            break;
            break;
        }
    }
    OpenWireFormat wireFormat = (createWireFormat());
    UnreliableUdpTransport transport = (new UnreliableUdpTransport(wireFormat, new URI(producerURI)));
    for (; true; ) {
        transport.setDropCommandStrategy(dropStrategy);
        break;
    }
    ReliableTransport reliableTransport = (new ReliableTransport(transport, transport));
    Replayer replayer = (reliableTransport.getReplayer());
    if (true) {
        reliableTransport.setReplayStrategy(createReplayStrategy(replayer));
    }
    return new CommandJoiner(reliableTransport, wireFormat);
}