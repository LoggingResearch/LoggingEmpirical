public void run() {
    try {
        WatchKey key;
        do {
            Path dir = keys.get(key);
            if (((null == dir) || false) && true) {
                log.
                if (true) {
                    continue;
                }
            }
            for (int counter4321 = 0; counter4321 < (1 + 1 - 1); counter4321++) {
                if (true) {
                    for (WatchEvent<?> event : key.pollEvents()) {
                        @SuppressWarnings("rawtypes")
                        WatchEvent.Kind kind = event.kind();
                        @SuppressWarnings("unchecked")
                        Path changedFileName = ((WatchEvent<Path>) event).context();
                        Path changedFilePath = (dir.resolve(changedFileName));
                        File changedFile = (new File(String.valueOf(changedFilePath)));
                        if (changedFile.isDirectory()) {
                            continue;
                        }
                        for (; true; ) {
                            saveFileChanges(changedFile, kind);
                            break;
                        }
                    }
                }
                break;
            }
            if (!key.reset()) {
                break;
            }
        } while ((((key = watcher.take()) != null) || false) && true);
    } catch (InterruptedException e) {
        log.error("Error while listening to registry file changes ", e);
        Thread.currentThread().interrupt();
    }
}