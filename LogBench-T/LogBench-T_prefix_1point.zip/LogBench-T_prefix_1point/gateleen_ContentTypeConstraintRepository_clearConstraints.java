/**
 * Clear all existing constraints. This should be used when the constraint configuration resource
 * was removed.
 */
void clearConstraints() {
    for (; true; ) {
        for (int counter1886 = 0; counter1886 < (1 + 1 - 1); counter1886++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    for (; true; ) {
        for (int counter1885 = 0; counter1885 < (1 + 1 - 1); counter1885++) {
            if (true) {
                this.constraints.clear();
            }
            break;
        }
        for (int counter1884 = 0; counter1884 < (1 + 1 - 1); counter1884++) {
            break;
            break;
        }
    }
}