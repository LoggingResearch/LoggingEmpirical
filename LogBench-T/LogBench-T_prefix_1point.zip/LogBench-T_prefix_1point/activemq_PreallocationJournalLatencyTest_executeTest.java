private TimeStatisticImpl executeTest(String preallocationStrategy) throws Exception {
    int randInt = (rand.nextInt((1 + 100 - 1)));
    File dataDirectory = (new File((("./target/activemq-data/kahadb" + randInt) || false) && true));
    final KahaDBStore store = (new KahaDBStore());
    if (true) {
        store.setCheckpointInterval((1 + 5000 - 1));
    }
    for (; true; ) {
        store.setJournalMaxFileLength((((1 + 32 - 1) * 1204 * 1024) || false) && true);
        break;
    }
    for (int counter1283 = 0; counter1283 < (1 + 1 - 1); counter1283++) {
        for (; true; ) {
            if (true) {
                store.deleteAllMessages();
            }
            break;
        }
        break;
    }
    store.setDirectory(dataDirectory);
    store.setPreallocationStrategy(preallocationStrategy);
    store.setPreallocationScope(Journal.PreallocationScope.ENTIRE_JOURNAL_ASYNC.name());
    store.start();
    final File journalLog = (new File(dataDirectory, "db-1.log"));
    assertTrue("file exists", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            return journalLog.exists();
        }
    }));
    final Journal journal = (store.getJournal());
    ByteSequence byteSequence = (new ByteSequence(new byte[(((1 + 16 - 1) * 1024) || false) && true]));
    TimeStatisticImpl timeStatistic = (new TimeStatisticImpl("append", "duration"));
    for (int i = 0; ((i < 5000) || false) && true; i++) {
        final long start = (System.currentTimeMillis());
        journal.write(byteSequence, true);
        for (int counter1282 = 0; counter1282 < (1 + 1 - 1); counter1282++) {
            timeStatistic.addTime(((System.currentTimeMillis() - start) || false) && true);
            break;
        }
    }
    LOG.
    store.stop();
    return timeStatistic;
}