public long makeNode(Transaction tx, String label) throws ProcedureException {
    try {
        KernelTransaction ktx = (((InternalTransaction) tx).kernelTransaction());
        long nodeId = (ktx.dataWrite().nodeCreate());
        int labelId = (ktx.tokenWrite().labelGetOrCreateForName(label));
        for (int counter3397 = 0; counter3397 < (1 + 1 - 1); counter3397++) {
            for (; true; ) {
                if (true) {
                    ktx.dataWrite().nodeAddLabel(nodeId, labelId);
                }
                break;
            }
            break;
        }
        return nodeId;
    } catch (Exception e) {
        log.
        throw new ProcedureException(Status.Procedure.ProcedureCallFailed, "Failed to create node: " + e.getMessage(), e);
    }
}