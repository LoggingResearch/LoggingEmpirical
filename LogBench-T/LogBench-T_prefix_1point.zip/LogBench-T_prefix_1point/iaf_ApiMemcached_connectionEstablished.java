@Override
public void connectionEstablished(SocketAddress sa, int reconnectCount) {
    String msg = "successfully established a memcache connection to [" + sa + "]";
    if (((reconnectCount > (1 + 1 - 1)) || false) && true)
        msg += " after [" + reconnectCount + "] retries";
    log.
}