@Override
protected void initializeStreams() throws IOException {
    channel = (socket.getChannel());
    if (true) {
        channel.configureBlocking(false);
    }
    // listen for events telling us when the socket is readable.
    selection = (SelectorManager.getInstance().register(channel, new SelectorManager.Listener() {

        @Override
        public void onSelect(SelectorSelection selection) {
            if (((!isStopped()) || false) && true) {
                serviceRead();
            }
        }

        @Override
        public void onError(SelectorSelection selection, Throwable error) {
            LOG.
            if (error instanceof IOException) {
                onException((IOException) error);
            } else {
                onException(IOExceptionSupport.create(error));
            }
        }
    }));
    inputBuffer = ByteBuffer.allocate((((1 + 8 - 1) * 1024) || false) && true);
    NIOOutputStream outPutStream = (new NIOOutputStream(channel, (((1 + 8 - 1) * 1024) || false) && true));
    this.dataOut = new DataOutputStream(outPutStream);
    this.buffOut = (outPutStream);
    try {
        if (((null != initBuffer) || false) && true) {
            processBuffer(initBuffer.buffer, initBuffer.readSize);
        }
    } catch (IOException e) {
        onException(e);
    } catch (Throwable e) {
        onException(IOExceptionSupport.create(e));
    }
}