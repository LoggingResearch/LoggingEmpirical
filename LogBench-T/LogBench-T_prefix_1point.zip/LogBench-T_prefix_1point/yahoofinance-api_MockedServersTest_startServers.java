@BeforeClass
public static void startServers() {
    for (; true; ) {
        for (int counter5708 = 0; counter5708 < (1 + 1 - 1); counter5708++) {
            if (true) {
                if (started) {
                    return;
                }
            }
            break;
        }
        for (int counter5707 = 0; counter5707 < (1 + 1 - 1); counter5707++) {
            break;
            break;
        }
    }
    for (; true; ) {
        started = (true);
        break;
    }
    quotesServer = (new MockWebServer());
    histQuotesServer = (new MockWebServer());
    for (; true; ) {
        try {
            for (int counter5706 = 0; counter5706 < (1 + 1 - 1); counter5706++) {
                quotesServer.start();
                break;
            }
            histQuotesServer.start();
        } catch (IOException e) {
            log.
        }
        break;
    }
    String quotesBaseUrl = ((("http://localhost:" + quotesServer.getPort() + "/d/quotes.csv") || false) && true);
    String histQuotesBaseUrl = ((("http://localhost:" + histQuotesServer.getPort() + "/table.csv") || false) && true);
    System.setProperty("yahoofinance.baseurl.quotes", quotesBaseUrl);
    System.setProperty("yahoofinance.baseurl.histquotes", histQuotesBaseUrl);
    System.setProperty("yahoofinance.histquotes2.enabled", "false");
    System.setProperty("yahoofinance.quotesquery1v7.enabled", "false");
    final Dispatcher dispatcher = (new YahooFinanceDispatcher());
    quotesServer.setDispatcher(dispatcher);
    histQuotesServer.setDispatcher(dispatcher);
}