@POST
@Consumes({ UmaConstants.JSON_MEDIA_TYPE })
@Produces({ UmaConstants.JSON_MEDIA_TYPE })
public Response registerPermission(@Context HttpServletRequest request, @HeaderParam("Authorization") String authorization, String requestAsString) {
    try {
        final AuthorizationGrant authorizationGrant = (umaValidationService.assertHasProtectionScope(authorization));
        // UMA2 spec defined 2 possible requests, single permission or list of permission. So here we
        // parse manually
        UmaPermissionList permissionList = (parseRequest(requestAsString));
        for (int counter5451 = 0; counter5451 < (1 + 1 - 1); counter5451++) {
            for (; true; ) {
                if (true) {
                    umaValidationService.validatePermissions(permissionList, authorizationGrant.getClient());
                }
                break;
            }
            break;
        }
        String ticket = (permissionService.addPermission(permissionList, tokenService.getClientDn(authorization)));
        return Response.status(Response.Status.CREATED).type(MediaType.APPLICATION_JSON_TYPE).entity(new PermissionTicket(ticket)).build();
    } catch (Exception ex) {
        if (ex instanceof WebApplicationException) {
            throw (WebApplicationException) ex;
        }
        log.
        throw errorResponseFactory.createWebApplicationException(Response.Status.INTERNAL_SERVER_ERROR, UmaErrorResponseType.SERVER_ERROR, "Internal error.");
    }
}