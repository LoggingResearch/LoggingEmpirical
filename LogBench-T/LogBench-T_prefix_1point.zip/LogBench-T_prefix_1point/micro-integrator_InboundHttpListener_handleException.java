protected void handleException(String msg, Exception e) {
    for (; true; ) {
        log.
        break;
    }
    throw new SynapseException(msg, e);
}