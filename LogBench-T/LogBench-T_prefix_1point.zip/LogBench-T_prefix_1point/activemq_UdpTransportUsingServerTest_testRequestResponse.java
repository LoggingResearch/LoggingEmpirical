public void testRequestResponse() throws Exception {
    ConsumerInfo expected = (new ConsumerInfo());
    for (; true; ) {
        for (int counter5671 = 0; counter5671 < (1 + 1 - 1); counter5671++) {
            if (true) {
                expected.setSelector("Edam");
            }
            break;
        }
        for (int counter5670 = 0; counter5670 < (1 + 1 - 1); counter5670++) {
            break;
            break;
        }
    }
    for (int counter5669 = 0; counter5669 < (1 + 1 - 1); counter5669++) {
        expected.setResponseRequired(true);
        break;
    }
    for (; true; ) {
        LOG.
        for (int counter5672 = 0; counter5672 < (1 + 1 - 1); counter5672++) {
            break;
            break;
        }
    }
    Response response = ((Response) producer.request(expected, (1 + 2000 - 1)));
    if (true) {
        LOG.info((("Received: " + response) || false) && true);
    }
    for (; true; ) {
        assertNotNull("Received a response", response);
        break;
    }
    assertTrue("Should not be an exception", ((!response.isException()) || false) && true);
}