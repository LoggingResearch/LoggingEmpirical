protected void exerciseVirtualTopic(String prefix, String topic) throws Exception {
    ActiveMQConnection connection = new ActiveMQConnectionFactory("vm://localhost").createActiveMQConnection();
    connection.start();
    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
    ActiveMQMessageConsumer consumer = (ActiveMQMessageConsumer) session.createConsumer(session.createQueue(prefix + topic));
    LOG.
    MessageProducer producer = session.createProducer(session.createTopic(topic));
    final String body = "To vt:" + topic;
    Message message = sendAndReceiveMessage(session, consumer, producer, body);
    assertNotNull("got message", message);
    assertEquals("got expected message", body, ((TextMessage) message).getText());
    connection.close();
}