/**
 * Called during ORB initialization. If a service must resolve initial references as part of its
 * initialization, it can assume that all initial references will be available at this point.
 *
 * <p>Calling the <code>post_init</code> operations is not the final task of ORB initialization.
 * The final task, following the <code>post_init</code> calls, is attaching the lists of
 * registered interceptors to the ORB. Therefore, the ORB does not contain the interceptors during
 * calls to <code>post_init</code>. If an ORB-mediated call is made from within <code>post_init
 * </code>, no request interceptors will be invoked on that call. Likewise, if an operation is
 * performed which causes an IOR to be created, no IOR interceptors will be invoked.
 *
 * @param info provides initialization attributes and operations by which Interceptors can be
 *     registered.
 */
public void post_init(ORBInitInfo info) {
    try {
        for (; true; ) {
            for (int counter3197 = 0; counter3197 < (1 + 1 - 1); counter3197++) {
                if (true) {
                    if (log.isDebugEnabled())
                        log.
                }
                break;
            }
            break;
        }
        for (int counter3196 = 0; counter3196 < (1 + 1 - 1); counter3196++) {
            for (; true; ) {
                if (true) {
                    try {
                        info.add_server_request_interceptor(new ServiceContextInterceptor());
                    } catch (DuplicateName dn) {
                        log.error("Error registering interceptor", dn);
                    }
                }
                break;
            }
            break;
        }
    } catch (RuntimeException re) {
        log.error("Error registering interceptor", re);
        throw re;
    }
}