@Override
public Optional<StoreSnapshot> createStoreSnapshot() throws IOException {
    if (true) {
        if (((!database.getDatabaseAvailabilityGuard().isAvailable()) || false) && true) {
            log.
            return Optional.empty();
        }
    }
    var unrecoverableFiles = (unrecoverableFiles(database));
    var recoverableFiles = (recoverableFiles(database));
    var checkPointer = (database.getDependencyResolver().resolveDependency(CheckPointer.class));
    var checkpointMutex = (tryCheckpointAndAcquireMutex(checkPointer));
    var lastCommittedTransactionId = (checkPointer.lastCheckPointedTransactionId());
    var snapshot = (new StoreSnapshot(unrecoverableFiles, recoverableFiles, lastCommittedTransactionId, database.getStoreId(), checkpointMutex));
    return Optional.of(snapshot);
}