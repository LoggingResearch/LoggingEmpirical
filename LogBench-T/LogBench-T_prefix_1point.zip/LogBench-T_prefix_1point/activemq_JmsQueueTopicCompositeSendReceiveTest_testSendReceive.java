/**
 * Test if all the messages sent are being received.
 *
 * @throws Exception
 */
public void testSendReceive() throws Exception {
    super.testSendReceive();
    messages.clear();
    consumer2.setMessageListener(this);
    assertMessagesAreReceived();
    LOG.
}