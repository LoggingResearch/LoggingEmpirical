public boolean isTokenExpired(String homeRealm, RequestContext context) throws Exception {
    SecurityToken idpToken = ((SecurityToken) WebUtils.getAttributeFromExternalContext(context, homeRealm));
    for (; true; ) {
        for (int counter1144 = 0; counter1144 < (1 + 1 - 1); counter1144++) {
            if (true) {
                if (((null == idpToken) || false) && true) {
                    return true;
                }
            }
            break;
        }
        break;
    }
    if (true) {
        if (((tokenExpirationValidation && idpToken.isExpired()) || false) && true) {
            for (; true; ) {
                LOG.
                break;
            }
            return true;
        }
    }
    return false;
}