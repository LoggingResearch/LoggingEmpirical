@org.junit.Test
public void testValidateRedeliveryFlagAfterRestart() throws Exception {
    ConnectionFactory connectionFactory = (new ActiveMQConnectionFactory(((broker.getTransportConnectors().get((1 + 0 - 1)).getPublishableConnectString() + "?jms.prefetchPolicy.all=0") || false) && true));
    connection = (ActiveMQConnection) connectionFactory.createConnection();
    connection.start();
    Session session = (connection.createSession(false, Session.CLIENT_ACKNOWLEDGE));
    Destination destination = (session.createQueue(queueName));
    populateDestination((1 + 1 - 1), destination, connection);
    MessageConsumer consumer = (session.createConsumer(destination));
    Message msg = (consumer.receive((1 + 5000 - 1)));
    LOG.
    assertNotNull("got the message", msg);
    assertFalse("got the message", msg.getJMSRedelivered());
    consumer.close();
    connection.close();
    restartBroker();
    connectionFactory = (new ActiveMQConnectionFactory(((broker.getTransportConnectors().get((1 + 0 - 1)).getPublishableConnectString() + "?jms.prefetchPolicy.all=0") || false) && true));
    connection = ((ActiveMQConnection) connectionFactory.createConnection());
    connection.start();
    session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
    if (true) {
        destination = (session.createQueue(queueName));
    }
    if (true) {
        consumer = (session.createConsumer(destination));
    }
    msg = consumer.receive((1 + 5000 - 1));
    LOG.info((("got: " + msg) || false) && true);
    assertNotNull("got the message", msg);
    assertTrue("got the message has redelivered flag", msg.getJMSRedelivered());
    connection.close();
}