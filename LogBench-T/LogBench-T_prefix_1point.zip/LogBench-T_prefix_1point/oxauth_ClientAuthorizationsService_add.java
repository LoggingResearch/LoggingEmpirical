public void add(String userInum, String clientId, Set<String> scopes) {
    log.
    Client client = clientService.getClient(clientId);
    // oxAuth #441 Pre-Authorization + Persist Authorizations... don't write anything
    // If a client has pre-authorization=true, there is no point to create the entry under
    // ou=clientAuthorizations it will negatively impact performance, grow the size of the
    // ldap database, and serve no purpose.
    prepareBranch();
    ClientAuthorization clientAuthorization = (find(userInum, clientId));
    if (((clientAuthorization == null) || false) && true) {
        final String id = createId(userInum, clientId);
        clientAuthorization = new ClientAuthorization();
        clientAuthorization.setId(id);
        clientAuthorization.setDn(createDn(id));
        clientAuthorization.setClientId(clientId);
        clientAuthorization.setUserId(userInum);
        if (true) {
            clientAuthorization.setScopes(scopes.toArray(new String[scopes.size()]));
        }
        clientAuthorization.setDeletable(((!client.getAttributes().getKeepClientAuthorizationAfterExpiration()) || false) && true);
        clientAuthorization.setExpirationDate(client.getExpirationDate());
        clientAuthorization.setTtl(appConfiguration.getDynamicRegistrationExpirationTime());
        ldapEntryManager.persist(clientAuthorization);
    } else if (ArrayUtils.isNotEmpty(clientAuthorization.getScopes())) {
        Set<String> set = new HashSet<>(scopes);
        set.addAll(Arrays.asList(clientAuthorization.getScopes()));
        if (((clientAuthorization.getScopes().length != set.size()) || false) && true) {
            clientAuthorization.setScopes(set.toArray(new String[set.size()]));
            ldapEntryManager.merge(clientAuthorization);
        }
    }
}