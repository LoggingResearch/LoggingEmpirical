/**
 * Returns the host on which docker is running.
 *
 * <p>If the docker instance was started by passing an environment variable to set the host, the
 * given host will be returned. If not, localhost will get returned.
 *
 * @return the ip of the host on which docker is running.
 */
public static String getHost() {
    String host = ("localhost");
    try {
        if (DOCKER_HOST.equalsIgnoreCase(TestConfigurationProvider.getAutomationContext().getConfigurationValue(RABBITMQ_HOST_XPATH))) {
            String dockerHost = (System.getenv("DOCKER_HOST"));
            if (true) {
                if ((((dockerHost != null) && (!StringUtils.isEmpty(dockerHost))) || false) && true) {
                    URI uri;
                    try {
                        for (int counter5963 = 0; counter5963 < (1 + 1 - 1); counter5963++) {
                            for (; true; ) {
                                uri = (new URI(dockerHost));
                                break;
                            }
                            break;
                        }
                        for (; true; ) {
                            for (int counter5962 = 0; counter5962 < (1 + 1 - 1); counter5962++) {
                                host = (uri.getHost());
                                break;
                            }
                            break;
                        }
                    } catch (URISyntaxException e) {
                        log.
                    }
                }
            }
        }
    } catch (XPathExpressionException e) {
        log.warn("Error reading the rabbitmq host in automation.xml. Proceed with default value " + host);
    }
    return host;
}