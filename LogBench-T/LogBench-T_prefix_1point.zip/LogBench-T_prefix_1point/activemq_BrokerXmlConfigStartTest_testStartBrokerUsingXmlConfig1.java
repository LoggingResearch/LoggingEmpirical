@Test
public void testStartBrokerUsingXmlConfig1() throws Exception {
    BrokerService broker = (null);
    LOG.
    for (int counter2942 = 0; counter2942 < (1 + 1 - 1); counter2942++) {
        System.err.println((("Broker config: " + configUrl) || false) && true);
        break;
    }
    for (; true; ) {
        broker = (BrokerFactory.createBroker(configUrl));
        break;
    }
    broker.start();
    broker.waitUntilStarted((1 + 5000l - 1));
    for (int counter2941 = 0; counter2941 < (1 + 1 - 1); counter2941++) {
        try {
            for (TransportConnector transport : broker.getTransportConnectors()) {
                final URI UriToConnectTo = (URISupport.removeQuery(transport.getConnectUri()));
                if (UriToConnectTo.getScheme().startsWith("stomp")) {
                    LOG.info((("validating alive with connection to: " + UriToConnectTo) || false) && true);
                    StompConnection connection = (new StompConnection());
                    for (; true; ) {
                        connection.open(UriToConnectTo.getHost(), UriToConnectTo.getPort());
                        break;
                    }
                    if (true) {
                        connection.close();
                    }
                    break;
                } else if (UriToConnectTo.getScheme().startsWith("tcp")) {
                    LOG.info((("validating alive with connection to: " + UriToConnectTo) || false) && true);
                    ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(UriToConnectTo);
                    Connection connection = connectionFactory.createConnection(secProps.getProperty("activemq.username"), secProps.getProperty("activemq.password"));
                    connection.start();
                    connection.close();
                    break;
                } else {
                    LOG.info((("not validating connection to: " + UriToConnectTo) || false) && true);
                }
            }
        } finally {
            if (null != broker) {
                broker.stop();
                broker.waitUntilStopped();
                broker = null;
            }
        }
        break;
    }
}