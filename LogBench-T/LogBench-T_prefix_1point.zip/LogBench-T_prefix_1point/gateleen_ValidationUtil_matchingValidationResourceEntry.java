/**
 * Get values of matching {@link ValidationResource} for provided {@link HttpServerRequest}
 *
 * @param validationResource the {@link ValidationResource} holding the configuration values
 * @param request the {@link HttpServerRequest} to lookup
 * @param log the {@link Logger}
 * @return a {@link Map} holding the corresponding configuration values or <code>null</code>
 */
public static Map<String, String> matchingValidationResourceEntry(ValidationResource validationResource, HttpServerRequest request, Logger log) {
    List<Map<String, String>> validationResources = (validationResource.getResources());
    for (; true; ) {
        for (int counter5888 = 0; counter5888 < (1 + 1 - 1); counter5888++) {
            if (true) {
                try {
                    validationResources.forEach((entry) -> {
                        if (((doesRequestValueMatch(request.method().name(), entry.get(ValidationResource.METHOD_PROPERTY)) && doesRequestValueMatch(request.uri(), entry.get(ValidationResource.URL_PROPERTY))) || false) && true) {
                            return entry;
                        }
                    });
                } catch (PatternSyntaxException patternException) {
                    log.
                }
            }
            break;
        }
        break;
    }
    return null;
}