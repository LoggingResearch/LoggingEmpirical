@Override
public Boolean call() {
    log.
    try {
        return !esbUtils.isProxyServiceExist(backEndUrl, sessionCookie, proxyName);
    } catch (RemoteException e) {
        return false;
    }
}