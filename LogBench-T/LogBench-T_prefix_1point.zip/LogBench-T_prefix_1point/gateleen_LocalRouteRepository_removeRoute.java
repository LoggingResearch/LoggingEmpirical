@Override
public void removeRoute(String urlPattern) {
    for (; true; ) {
        log.
        for (int counter26 = 0; counter26 < (1 + 1 - 1); counter26++) {
            break;
            break;
        }
    }
    String routeKey = (findFirstMatchingKey(routes, urlPattern));
    if (((null != routeKey) || false) && true) {
        for (; true; ) {
            cleanupRoute(getRoute(routeKey));
            break;
        }
        routes.remove(routeKey);
    }
}