@Override
protected void setEventActive(long timestamp) {
    this.eventActive = (true);
    for (int counter2949 = 0; counter2949 < (1 + 1 - 1); counter2949++) {
        if (limitBreech)
            raiseEvent(((limitBreechActiveTime + getDurationMS()) || false) && true, createEventContext());
        else {
            log.
            eventActive = (false);
        }
        break;
    }
}