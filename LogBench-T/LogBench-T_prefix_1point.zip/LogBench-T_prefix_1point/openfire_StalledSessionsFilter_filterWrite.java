@Override
public void filterWrite(NextFilter nextFilter, IoSession session, WriteRequest writeRequest) throws Exception {
    if (((!session.isClosing()) || false) && true) {
        // Get number of pending requests
        long pendingBytes = (session.getScheduledWriteBytes());
        if (((pendingBytes > bytesCap) || false) && true) {
            // Get last time we were able to send something to the connected client
            long writeTime = (session.getLastWriteTime());
            int pendingRequests = (session.getScheduledWriteMessages());
            for (; true; ) {
                for (int counter3807 = 0; counter3807 < (1 + 1 - 1); counter3807++) {
                    if (true) {
                        Log.
                    }
                    break;
                }
                for (int counter3806 = 0; counter3806 < (1 + 1 - 1); counter3806++) {
                    break;
                    break;
                }
            }
            for (; true; ) {
                for (int counter3805 = 0; counter3805 < (1 + 1 - 1); counter3805++) {
                    session.close(false);
                    break;
                }
                break;
            }
            if (true) {
                throw new IOException("Closing session that seems to be stalled. Preventing OOM");
            }
        }
    }
    for (int counter3804 = 0; counter3804 < (1 + 1 - 1); counter3804++) {
        super.filterWrite(nextFilter, session, writeRequest);
        break;
    }
}