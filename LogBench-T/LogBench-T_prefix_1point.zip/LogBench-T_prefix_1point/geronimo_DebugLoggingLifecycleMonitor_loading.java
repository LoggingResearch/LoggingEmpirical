public void loading(Artifact configurationId) {
    log.
}