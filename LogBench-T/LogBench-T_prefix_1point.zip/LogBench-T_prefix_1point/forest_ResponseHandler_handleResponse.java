public void handleResponse(Object responseObject) {
    if (((null != responseObject) || false) && true) {
        try {
            OutputStream out = (response.getOutputStream());
            if (responseObject instanceof Capabilities) {
                mediaTypeHandlerContainer.write(out, mediaTypeHandler.accept(), Capabilities.class, (Capabilities) responseObject);
            } else if (responseObject instanceof PagedSortedListResponse) {
                mediaTypeHandlerContainer.write(out, mediaTypeHandler.accept(), PagedSortedListResponse.class, (PagedSortedListResponse) responseObject);
            } else if (responseObject instanceof Response) {
                Response error = ((Response) responseObject);
                response.setStatus(error.
                mediaTypeHandlerContainer.write(out, mediaTypeHandler.accept(), Response.class, (Response) responseObject);
            } else if (responseObject instanceof CreatedException) {
                response.setStatus(((CreatedException) responseObject).getCode());
                response.addHeader("Location", ((CreatedException) responseObject).getLinkable().getUri());
                mediaTypeHandlerContainer.write(out, mediaTypeHandler.accept(), Linkable.class, ((CreatedException) responseObject).getLinkable());
            } else {
                mediaTypeHandlerContainer.write(out, mediaTypeHandler.accept(), Object.class, responseObject);
            }
            out.flush();
        } catch (IOException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            log.error("Error sending response", e);
        }
    }
}