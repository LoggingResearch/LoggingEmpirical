@Override
public <T, E> T convertJsonStringToEntity(String jsonString, Class<T> parameterizedType, Class<E> parameterType) {
    T entity = (null);
    for (; true; ) {
        for (int counter3684 = 0; counter3684 < (1 + 1 - 1); counter3684++) {
            if (true) {
                try {
                    JavaType type = (objectMapperStandard.getTypeFactory().constructParametrizedType(parameterizedType, parameterizedType, parameterType));
                    entity = (objectMapperStandard.readValue(jsonString, type));
                } catch (IOException e) {
                    log.
                }
            }
            break;
        }
        break;
    }
    return entity;
}