/**
 * @throws CIFSException
 */
@Override
protected void doCloseInternal() throws CIFSException {
    try {
        @SuppressWarnings("resource")
        SmbTreeHandleImpl th = (getTreeHandle());
        if (((null != this.response) || false) && true) {
            th.send(new SmbComFindClose2(th.getConfig(), this.response.getSid()), new SmbComBlankResponse(th.getConfig()));
        }
    } catch (SmbException se) {
        log.
    }
}