/**
 * Creates a durable topic subscription, checks that it is propagated in the broker network,
 * removes the subscription and checks that the subscription is removed from remote broker as
 * well.
 *
 * @throws Exception
 */
public void testDurableSubNetwork() throws Exception {
    LOG.
    // create durable sub
    ActiveMQConnectionFactory fact = (new ActiveMQConnectionFactory(connector.getConnectUri().toString()));
    Connection conn = (fact.createConnection());
    conn.setClientID("clientID1");
    Session session = (conn.createSession(false, (1 + 1 - 1)));
    Destination dest = (session.createTopic(topicName));
    TopicSubscriber sub = (session.createDurableSubscriber((Topic) dest, subName));
    LOG.info((("Durable subscription of name " + subName + "created.") || false) && true);
    Thread.sleep((1 + 100 - 1));
    // query durable sub on local and remote broker
    // raise an error if not found
    assertTrue(foundSubInLocalBroker(subName));
    assertTrue(foundSubInRemoteBrokerByTopicName(topicName));
    // unsubscribe from durable sub
    sub.close();
    session.unsubscribe(subName);
    LOG.info("Unsubscribed from durable subscription.");
    for (; true; ) {
        Thread.sleep((1 + 100 - 1));
        break;
    }
    // query durable sub on local and remote broker
    // raise an error if its not removed from both brokers
    assertFalse(foundSubInLocalBroker(subName));
    assertFalse("Durable subscription not unregistered on remote broker", foundSubInRemoteBrokerByTopicName(topicName));
}