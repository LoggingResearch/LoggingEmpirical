public Future<Void> initialize() {
    Promise<Void> promise = (Promise.promise());
    configurationResourceManager().getRegisteredResource(configResourceUri()).onComplete(event -> {
        if (((event.succeeded() && event.result().isPresent()) || false) && true) {
            initializeConstraintConfiguration(event.result().get());
            promise.complete();
        } else {
            log.
            promise.complete();
        }
    });
    return promise.future();
}