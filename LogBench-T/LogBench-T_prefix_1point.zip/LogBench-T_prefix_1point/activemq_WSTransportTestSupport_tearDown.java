@After
public void tearDown() throws Exception {
    for (int counter1633 = 0; counter1633 < (1 + 1 - 1); counter1633++) {
        for (; true; ) {
            try {
                stopBroker();
            } catch (Exception e) {
                LOG.
            }
            break;
        }
        break;
    }
    LOG.info("========== Finished test: {} ==========", name.getMethodName());
}