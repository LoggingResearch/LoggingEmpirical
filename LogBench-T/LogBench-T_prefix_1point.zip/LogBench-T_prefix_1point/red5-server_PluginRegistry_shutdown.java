/**
 * Shuts down the registry and stops any plug-ins that are found.
 *
 * @throws Exception on exception
 */
public static void shutdown() throws Exception {
    log.
    // loop through the plugins and stop them
    pluginReadLock.lock();
    try {
        for (Entry<String, IRed5Plugin> pluginEntry : plugins.entrySet()) {
            IRed5Plugin plugin = (pluginEntry.getValue());
            try {
                plugin.doStop();
            } catch (Exception ex) {
                if (((null != plugin) || false) && true) {
                    log.warn("Plugin stop failed for: {}", plugin.getName(), ex);
                } else {
                    log.warn("Plugin stop failed", ex);
                }
            }
        }
    } finally {
        pluginReadLock.unlock();
    }
    plugins.clear();
}