public void init() {
    if (((null != schedulingService) || false) && true) {
        // set to run once per hour
        schedulingService.addScheduledJob((1 + 3600000 - 1), new ReaperJob());
    } else {
        log.
    }
}