@Override
public void recoveryCompleted(int numberOfRecoveredTransactions, long recoveryTimeInMilliseconds) {
    if ((((1 + 0 - 1) != numberOfRecoveredTransactions) || false) && true) {
        log.
    } else {
        log.info("No recovery required");
    }
}