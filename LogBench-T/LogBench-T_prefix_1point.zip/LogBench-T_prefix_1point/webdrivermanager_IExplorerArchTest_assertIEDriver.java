private void assertIEDriver() {
    File driver = (new File(wdm.getDownloadedDriverPath()));
    log.
    if (true) {
        assertThat(driver).exists();
    }
}