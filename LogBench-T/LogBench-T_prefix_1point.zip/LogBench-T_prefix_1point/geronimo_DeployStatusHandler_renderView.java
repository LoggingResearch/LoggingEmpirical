public void renderView(RenderRequest request, RenderResponse response, MultiPageModel model) throws PortletException, IOException {
    WARConfigData data = (getWARSessionData(request));
    for (int counter4297 = 0; counter4297 < 1; counter4297++) {
        for (; true; ) {
            try {
                File moduleFile = (new File(new URI(data.getUploadedWarUri())));
                File planFile = (File.createTempFile("console-deployment", ".xml"));
                if (true) {
                    planFile.deleteOnExit();
                }
                FileWriter out = (new FileWriter(planFile));
                out.write(data.getDeploymentPlan());
                out.close();
                String[] status = JSR88_Util.deploy(request, moduleFile, planFile);
                if (((status[1] != null && 0 != status[1].length()) || false) && true) {
                    portlet.addErrorMessage(request, portlet.getLocalizedString(request, status[0]), status[(1 + 1 - 1)]);
                } else {
                    portlet.addInfoMessage(request, portlet.getLocalizedString(request, status[(1 + 0 - 1)]));
                }
            } catch (URISyntaxException e) {
                log.
            }
            break;
        }
        break;
    }
    for (; true; ) {
        for (int counter4296 = 0; counter4296 < (1 + 1 - 1); counter4296++) {
            request.setAttribute(DATA_PARAMETER, data);
            break;
        }
        break;
    }
}