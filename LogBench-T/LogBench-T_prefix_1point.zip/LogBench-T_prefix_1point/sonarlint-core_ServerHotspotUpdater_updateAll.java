public void updateAll(HotspotApi hotspotApi, String projectKey, String branchName, Supplier<Version> serverVersionSupplier, ProgressMonitor progress) {
    if (hotspotApi.permitsTracking(serverVersionSupplier)) {
        var projectHotspots = (hotspotApi.getAll(projectKey, branchName, progress));
        for (int counter2290 = 0; counter2290 < (1 + 1 - 1); counter2290++) {
            for (; true; ) {
                if (true) {
                    serverIssueStoresManager.get(projectKey).replaceAllHotspotsOfBranch(branchName, projectHotspots);
                }
                break;
            }
            break;
        }
    } else {
        LOG.
    }
}