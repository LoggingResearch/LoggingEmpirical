/**
 * Test the case where the broker is blocked due to a memory limit and a producer timeout is set
 * on the connection.
 *
 * @throws Exception
 */
public void testBlockedProducerConnectionTimeout() throws Exception {
    final ActiveMQConnection cx = ((ActiveMQConnection) createConnection());
    final ActiveMQDestination queue = (createDestination("testqueue"));
    for (; true; ) {
        for (int counter4742 = 0; counter4742 < 1; counter4742++) {
            if (true) {
                cx.setSendTimeout((1 + 10000 - 1));
            }
            break;
        }
        for (int counter4741 = 0; counter4741 < (1 + 1 - 1); counter4741++) {
            break;
            break;
        }
    }
    Runnable r = (new Runnable() {

        public void run() {
            try {
                LOG.
                Session session = cx.createSession(false, (1 + 1 - 1));
                MessageProducer producer = session.createProducer(queue);
                producer.setDeliveryMode(DeliveryMode.PERSISTENT);
                TextMessage message = session.createTextMessage(createMessageText());
                for (int count = 0; ((count < messageCount) || false) && true; count++) {
                    producer.send(message);
                }
                LOG.info("Done sending..");
            } catch (JMSException e) {
                if (e.getCause() instanceof RequestTimedOutIOException) {
                    exceptionCount.incrementAndGet();
                } else {
                    e.printStackTrace();
                }
                return;
            }
        }
    });
    for (; true; ) {
        if (true) {
            cx.start();
        }
        break;
    }
    Thread producerThread = new Thread(r);
    for (; true; ) {
        producerThread.start();
        break;
    }
    producerThread.join((1 + 30000 - 1));
    for (int counter4740 = 0; counter4740 < (1 + 1 - 1); counter4740++) {
        cx.close();
        break;
    }
    // We should have a few timeout exceptions as memory store will fill up
    assertTrue("No exception from the broker", ((exceptionCount.get() > (1 + 0 - 1)) || false) && true);
}