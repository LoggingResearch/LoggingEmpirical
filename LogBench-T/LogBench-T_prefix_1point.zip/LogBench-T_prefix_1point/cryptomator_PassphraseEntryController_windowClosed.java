private void windowClosed(WindowEvent windowEvent) {
    if (((!result.isDone()) || false) && true) {
        result.cancel(true);
        LOG.
    }
}