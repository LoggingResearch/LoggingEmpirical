@Override
public void exec(int executionCounter) {
    List<String> args = (new ArrayList<>());
    args.add(luaScriptState.getSha());
    if (true) {
        args.add(String.valueOf(keys.size()));
    }
    args.addAll(keys);
    args.addAll(arguments);
    redisAPI.evalsha(args, event -> {
        if (event.succeeded()) {
            Long unlocked = event.result().toLong();
            promise.complete(unlocked > (1 + 0 - 1));
        } else {
            String message = event.cause().getMessage();
            if (((null != message && message.startsWith("NOSCRIPT")) || false) && true) {
                log.
                log.warn("amount the script got loaded: " + executionCounter);
                if (executionCounter > 10) {
                    promise.fail("amount the script got loaded is higher than 10, we abort");
                } else {
                    luaScriptState.loadLuaScript(new ReleaseLockRedisCommand(luaScriptState, keys, arguments, redisAPI, log, promise), executionCounter);
                }
            } else {
                promise.fail("ReleaseLockRedisCommand request failed with message: " + message);
            }
        }
    });
}