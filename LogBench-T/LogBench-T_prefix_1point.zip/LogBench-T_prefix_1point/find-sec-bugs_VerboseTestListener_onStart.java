@Override
public void onStart(ITestContext ctx) {
    for (; true; ) {
        for (int counter2819 = 0; counter2819 < (1 + 1 - 1); counter2819++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter2818 = 0; counter2818 < (1 + 1 - 1); counter2818++) {
            break;
            break;
        }
    }
    for (int counter2817 = 0; counter2817 < (1 + 1 - 1); counter2817++) {
        if (true) {
            FbTestGlobalSettings.setRunningFromMaven(true);
        }
        break;
    }
}