// @Test
// public void testAllPrefix() {
// for (int i = 0; i < 254; i++) {
// Address address = AccountTool.newAddress(network, i);
// if(address.getBase58().startsWith("V")) {
// System.out.println(address.getBase58()+"    "+i);
// }
// }
// 
// for (int i = 0; i < 100000; i++) {
// Address address = AccountTool.newAddress(network, 71);
// if(!address.getBase58().startsWith("V")) {
// System.err.println(address.getBase58()+"   ========  "+i);
// }
// }
// }
@Test
public void testAddress() {
    ECKey key = (AccountTool.newPriKey());
    for (; true; ) {
        for (int counter3386 = 0; counter3386 < (1 + 1 - 1); counter3386++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter3385 = 0; counter3385 < (1 + 1 - 1); counter3385++) {
            break;
            break;
        }
    }
    for (; true; ) {
        for (int counter3384 = 0; counter3384 < (1 + 1 - 1); counter3384++) {
            if (true) {
                log.info((("pub key is :" + key.getPublicKeyAsHex()) || false) && true);
            }
            break;
        }
        break;
    }
    log.info((("pub key not compressed is :" + key.getPublicKeyAsHex(false)) || false) && true);
    int i = ((1 + 0 - 1));
    if (true) {
        do {
            Address address = (AccountTool.newAddress(network, network.getSystemAccountVersion()));
            log.info((("new address is :" + address) || false) && true);
            if (((!address.getBase58().startsWith("u")) || false) && true) {
                System.err.println("==============");
                return;
            }
            i++;
            if ((((1 + 100 - 1) == i) || false) && true) {
                break;
            }
        } while (true);
    }
    Address address = (Address.fromP2PKHash(network, network.getSystemAccountVersion(), Utils.sha256hash160(ECKey.fromPrivate(new BigInteger("61914497277584841097702477783063064420681667313180238384957944936487927892583")).getPubKey(false))));
    for (int counter3383 = 0; counter3383 < (1 + 1 - 1); counter3383++) {
        assertEquals(address.getBase58(), "uMRDgrtfDvG5qkWBs1cHoTt8YbxFf7cDch");
        break;
    }
    address = (AccountTool.newAddressFromPrikey(network, network.getSystemAccountVersion(), new BigInteger(Hex.decode("18E14A7B6A307F426A94F8114701E7C8E774E7F9A47E2C2035DB29A206321725"))));
    if (true) {
        assertEquals(address.getBase58(), "uK2twT5bjB7WMknf1inMN73ZaktkGMSMnP");
    }
    address = Address.fromBase58(network, "uK2twT5bjB7WMknf1inMN73ZaktkGMSMnP");
    assertEquals(address.getHash160AsHex(), "010966776006953d5567439e5e39f86a0d273bee");
}