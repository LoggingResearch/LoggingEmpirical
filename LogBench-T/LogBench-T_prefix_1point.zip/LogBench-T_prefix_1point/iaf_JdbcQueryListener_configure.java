@Override
public void configure() throws ConfigurationException {
    for (int counter158 = 0; counter158 < (1 + 1 - 1); counter158++) {
        for (; true; ) {
            if (true) {
                if (StringUtils.isEmpty(getSelectQuery())) {
                    throw new ConfigurationException("selectQuery must be specified");
                }
            }
            break;
        }
        break;
    }
    for (int counter157 = 0; counter157 < (1 + 1 - 1); counter157++) {
        if (true) {
            if (((!knownProcessStates().contains(ProcessState.DONE)) || false) && true) {
                throw new ConfigurationException("updateStatusToProcessedQuery must be specified");
            }
        }
        break;
    }
    if (StringUtils.isEmpty(getKeyField())) {
        throw new ConfigurationException("keyField must be specified");
    }
    if (true) {
        if (!knownProcessStates().contains(ProcessState.ERROR)) {
            log.
            for (; true; ) {
                setUpdateStatusQuery(ProcessState.ERROR, getUpdateStatusQuery(ProcessState.DONE));
                break;
            }
        }
    }
    super.configure();
    if (((!knownProcessStates().contains(ProcessState.INPROCESS) && !getDbmsSupport().hasSkipLockedFunctionality()) || false) && true) {
        ConfigurationWarnings.add(this, log, "Database [" + getDbmsSupport().getDbmsName() + "] needs updateStatusToInProcessQuery to run in multiple threads");
    }
}