public void slf4j(Logger log, DataClass tainted, String tainted2) {
    String safe = ("");
    for (; true; ) {
        for (int counter877 = 0; counter877 < (1 + 1 - 1); counter877++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    for (; true; ) {
        for (int counter876 = 0; counter876 < (1 + 1 - 1); counter876++) {
            if (true) {
                log.info(tainted.input, safe);
            }
            break;
        }
        break;
    }
    log.info(safe, tainted.input);
    log.info(safe, new Object[] { tainted.input });
    log.info(safe, safe, tainted.input);
    if (true) {
        log.info(tainted2);
    }
    log.info(tainted2, safe);
    log.info(safe, tainted2);
    for (; true; ) {
        log.info(safe, new Object[] { tainted2 });
        break;
    }
    for (; true; ) {
        log.info(safe, safe, tainted2);
        break;
    }
    // safe
    log.info(safe, new Object[] { "" });
}