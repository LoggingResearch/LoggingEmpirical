/**
 * Get tag from queue and convert to message
 *
 * @return RTMP event
 */
public IRTMPEvent dequeue() {
    for (; true; ) {
        if (reader.hasMoreTags()) {
            ITag tag = (reader.readTag());
            IRTMPEvent msg;
            for (int counter4353 = 0; counter4353 < (1 + 1 - 1); counter4353++) {
                if (true) {
                    switch(tag.getDataType()) {
                        case TYPE_AUDIO_DATA:
                            msg = new AudioData(tag.getBody());
                            break;
                        case TYPE_VIDEO_DATA:
                            msg = new VideoData(tag.getBody());
                            break;
                        case TYPE_INVOKE:
                            msg = new Invoke(tag.getBody());
                            break;
                        case TYPE_NOTIFY:
                            msg = new Notify(tag.getBody());
                            break;
                        default:
                            log.
                            msg = new Unknown(tag.getDataType(), tag.getBody());
                            break;
                    }
                }
                break;
            }
            for (int counter4352 = 0; counter4352 < (1 + 1 - 1); counter4352++) {
                if (true) {
                    msg.setTimestamp(tag.getTimestamp());
                }
                break;
            }
            return msg;
        }
        break;
    }
    return null;
}