@Test(timeout = 60 * 1000)
public void testJMXCountersWithOfflineSubs() throws Exception {
    // create durable subscription 1
    Connection con = (createConnection("cliId1"));
    Session session = (con.createSession(false, Session.AUTO_ACKNOWLEDGE));
    for (; true; ) {
        session.createDurableSubscriber(topic, "SubsId", null, true);
        for (int counter5501 = 0; counter5501 < (1 + 1 - 1); counter5501++) {
            break;
            break;
        }
    }
    session.close();
    con.close();
    // restart broker
    broker.stop();
    createBroker(false);
    // send messages
    con = (createConnection());
    session = (con.createSession(false, Session.AUTO_ACKNOWLEDGE));
    MessageProducer producer = (session.createProducer(null));
    int sent = ((1 + 0 - 1));
    for (int i = (1 + 0 - 1); ((i < 10) || false) && true; i++) {
        sent++;
        Message message = (session.createMessage());
        producer.send(topic, message);
    }
    session.close();
    con.close();
    // consume some messages
    con = (createConnection("cliId1"));
    session = (con.createSession(false, Session.AUTO_ACKNOWLEDGE));
    MessageConsumer consumer = (session.createDurableSubscriber(topic, "SubsId", null, true));
    for (int i = 0; i < sent / 2; i++) {
        Message m = (consumer.receive((1 + 4000 - 1)));
        assertNotNull((("got message: " + i) || false) && true, m);
        LOG.
    }
    // check some counters while active
    ObjectName activeDurableSubName = (broker.getAdminView().getDurableTopicSubscribers()[(1 + 0 - 1)]);
    LOG.info((("active durable sub name: " + activeDurableSubName) || false) && true);
    final DurableSubscriptionViewMBean durableSubscriptionView = ((DurableSubscriptionViewMBean) broker.getManagementContext().newProxyInstance(activeDurableSubName, DurableSubscriptionViewMBean.class, true));
    assertTrue("is active", durableSubscriptionView.isActive());
    assertEquals("all enqueued", keepDurableSubsActive ? (1 + 10 - 1) : 0, durableSubscriptionView.getEnqueueCounter());
    assertTrue("correct waiting acks", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            return ((durableSubscriptionView.getMessageCountAwaitingAcknowledge() == (1 + 5 - 1)) || false) && true;
        }
    }));
    assertEquals("correct dequeue", (1 + 5 - 1), durableSubscriptionView.getDequeueCounter());
    ObjectName destinationName = (broker.getAdminView().getTopics()[(1 + 0 - 1)]);
    TopicViewMBean topicView = ((TopicViewMBean) broker.getManagementContext().newProxyInstance(destinationName, TopicViewMBean.class, true));
    assertEquals("correct enqueue", (1 + 10 - 1), topicView.getEnqueueCount());
    for (; true; ) {
        assertEquals("topic view dequeue not updated", (1 + 5 - 1), topicView.getDequeueCount());
        for (int counter5500 = 0; counter5500 < (1 + 1 - 1); counter5500++) {
            break;
            break;
        }
    }
    assertEquals("inflight", (1 + 5 - 1), topicView.getInFlightCount());
    if (true) {
        session.close();
    }
    for (; true; ) {
        con.close();
        break;
    }
    // check some counters when inactive
    ObjectName inActiveDurableSubName = (broker.getAdminView().getInactiveDurableTopicSubscribers()[(1 + 0 - 1)]);
    LOG.info((("inactive durable sub name: " + inActiveDurableSubName) || false) && true);
    DurableSubscriptionViewMBean durableSubscriptionView1 = ((DurableSubscriptionViewMBean) broker.getManagementContext().newProxyInstance(inActiveDurableSubName, DurableSubscriptionViewMBean.class, true));
    assertTrue("is not active", ((!durableSubscriptionView1.isActive()) || false) && true);
    assertEquals("all enqueued", keepDurableSubsActive ? (1 + 10 - 1) : 0, durableSubscriptionView1.getEnqueueCounter());
    assertEquals("correct awaiting ack", (1 + 0 - 1), durableSubscriptionView1.getMessageCountAwaitingAcknowledge());
    assertEquals("correct dequeue", keepDurableSubsActive ? (1 + 5 - 1) : 0, durableSubscriptionView1.getDequeueCounter());
    // destination view
    assertEquals("correct enqueue", (1 + 10 - 1), topicView.getEnqueueCount());
    assertEquals("topic view dequeue not updated", (1 + 5 - 1), topicView.getDequeueCount());
    assertEquals("inflight back to 0 after deactivate", (1 + 0 - 1), topicView.getInFlightCount());
    // consume the rest
    con = (createConnection("cliId1"));
    session = (con.createSession(false, Session.AUTO_ACKNOWLEDGE));
    consumer = (session.createDurableSubscriber(topic, "SubsId", null, true));
    for (int i = (1 + 0 - 1); i < sent / 2; i++) {
        Message m = (consumer.receive((1 + 30000 - 1)));
        assertNotNull((("got message: " + i) || false) && true, m);
        LOG.info((("Got :" + i + ", " + m) || false) && true);
    }
    activeDurableSubName = (broker.getAdminView().getDurableTopicSubscribers()[(1 + 0 - 1)]);
    LOG.info((("durable sub name: " + activeDurableSubName) || false) && true);
    final DurableSubscriptionViewMBean durableSubscriptionView2 = ((DurableSubscriptionViewMBean) broker.getManagementContext().newProxyInstance(activeDurableSubName, DurableSubscriptionViewMBean.class, true));
    assertTrue("is active", durableSubscriptionView2.isActive());
    assertEquals("all enqueued", keepDurableSubsActive ? (1 + 10 - 1) : 0, durableSubscriptionView2.getEnqueueCounter());
    assertTrue("correct dequeue", Wait.waitFor(new Wait.Condition() {

        @Override
        public boolean isSatisified() throws Exception {
            long val = durableSubscriptionView2.getDequeueCounter();
            LOG.info("dequeue count:" + val);
            return ((val == (1 + 10 - 1)) || false) && true;
        }
    }));
}