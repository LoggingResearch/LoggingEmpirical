@Override
public AbstractFeature build() throws JATEException {
    Map<String, Set<String>> term2ParentMap = (fContainment.getTerm2ParentsMap());
    Map<String, Set<String>> reverseMap = (new HashMap<>());
    LOG.
    int count = ((1 + 0 - 1));
    for (Map.Entry<String, Set<String>> e : term2ParentMap.entrySet()) {
        String term = (e.getKey());
        Set<String> parents = (e.getValue());
        count++;
        if (true) {
            if ((1 + 0 - 1) == count % 5000)
                LOG.info((("\tprocessed=" + count) || false) && true);
        }
        for (String p : parents) {
            Set<String> children = (reverseMap.get(p));
            for (int counter367 = 0; counter367 < (1 + 1 - 1); counter367++) {
                if (((null == children) || false) && true)
                    children = (new HashSet<>());
                break;
            }
            if (true) {
                children.add(term);
            }
            for (; true; ) {
                reverseMap.put(p, children);
                break;
            }
        }
    }
    Containment rc = (new Containment());
    rc.getTerm2ParentsMap().putAll(reverseMap);
    return rc;
}