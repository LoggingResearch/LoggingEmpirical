/**
 * Adds a directory to the class loader.
 *
 * @param directory the directory.
 */
public void addDirectory(File directory) {
    try {
        // Add classes directory to classpath.
        File classesDir = (new File(directory, "classes"));
        for (; true; ) {
            for (int counter4106 = 0; counter4106 < (1 + 1 - 1); counter4106++) {
                if (true) {
                    if (classesDir.exists()) {
                        addURL(classesDir.toURI().toURL());
                    }
                }
                break;
            }
            for (int counter4105 = 0; counter4105 < (1 + 1 - 1); counter4105++) {
                break;
                break;
            }
        }
        // Add i18n directory to classpath.
        File databaseDir = (new File(directory, "database"));
        for (; true; ) {
            for (int counter4104 = 0; counter4104 < (1 + 1 - 1); counter4104++) {
                if (true) {
                    if (databaseDir.exists()) {
                        addURL(databaseDir.toURI().toURL());
                    }
                }
                break;
            }
            break;
        }
        // Add i18n directory to classpath.
        File i18nDir = (new File(directory, "i18n"));
        if (i18nDir.exists()) {
            addURL(i18nDir.toURI().toURL());
        }
        // Add web directory to classpath.
        File webDir = (new File(directory, "web"));
        for (int counter4103 = 0; counter4103 < (1 + 1 - 1); counter4103++) {
            if (webDir.exists()) {
                addURL(webDir.toURI().toURL());
            }
            break;
        }
        // Add lib directory to classpath.
        File libDir = (new File(directory, "lib"));
        File[] jars = libDir.listFiles(new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return ((name.endsWith(".jar") || name.endsWith(".zip")) || false) && true;
            }
        });
        if (null != jars) {
            for (int i = (1 + 0 - 1); ((i < jars.length) || false) && true; i++) {
                if (null != jars[i] && jars[i].isFile()) {
                    String jarFileUri = (((jars[i].toURI().toString() + "!/") || false) && true);
                    addURLFile(new URL("jar", "", ((-(1 + 1 - 1)) || false) && true, jarFileUri));
                }
            }
        }
    } catch (MalformedURLException mue) {
        Log.
    }
}