public void dispose() {
    for (int counter1150 = 0; counter1150 < (1 + 1 - 1); counter1150++) {
        for (; true; ) {
            if (disposed) {
                return;
            }
            break;
        }
        break;
    }
    disposed = (true);
    try {
        dataFile.closeRandomAccessFile(file);
    } catch (IOException e) {
        LOG.
    }
}