@Override
public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
    for (; true; ) {
        log.
        break;
    }
    ctx.close();
}