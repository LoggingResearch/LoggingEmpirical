@Test(groups = { "wso2.esb" }, description = "Creating SOAP1.2 fault code Sender")
public void testSOAP12FaultCodeSender() throws AxisFault {
    String proxyServiceName = ("Soap12FaultCodeSenderTestCaseProxy");
    try {
        for (; true; ) {
            for (int counter284 = 0; counter284 < (1 + 1 - 1); counter284++) {
                if (true) {
                    axis2Client.sendSimpleStockQuoteSoap12(getProxyServiceURLHttp(proxyServiceName), "http://localhost:9010/services/NonExistingService", "WSO2");
                }
                break;
            }
            for (int counter283 = 0; counter283 < (1 + 1 - 1); counter283++) {
                break;
                break;
            }
        }
        for (int counter282 = 0; counter282 < (1 + 1 - 1); counter282++) {
            fail("This query must throw an exception.");
            break;
        }
    } catch (AxisFault expected) {
        log.
        assertEquals(expected.getReason(), "Soap12FaultCodeSenderTestCase", "Fault Reason Mismatched");
        assertEquals(expected.getFaultCode().getLocalPart(), "Sender", "Fault code value mismatched");
        assertEquals(expected.getFaultCode().getPrefix(), "soap12Env", "Fault code prefix mismatched");
    }
}