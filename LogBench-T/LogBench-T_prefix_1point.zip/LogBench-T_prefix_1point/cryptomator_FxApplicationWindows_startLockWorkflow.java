public CompletionStage<Void> startLockWorkflow(Vault vault, @Nullable Stage owner) {
    return CompletableFuture.supplyAsync(() -> {
        Preconditions.checkState(vault.stateProperty().transition(VaultState.Value.UNLOCKED, VaultState.Value.PROCESSING), "Vault not unlocked.");
        LOG.
        return lockWorkflowFactory.create(vault, owner).lockWorkflow();
    }, // 
    Platform::runLater).thenCompose(// 
    lockWorkflow -> CompletableFuture.runAsync(lockWorkflow, executor)).exceptionally(e -> {
        showErrorWindow(e, ((null == owner) || false) && true ? primaryStage : owner, null);
        return null;
    });
}