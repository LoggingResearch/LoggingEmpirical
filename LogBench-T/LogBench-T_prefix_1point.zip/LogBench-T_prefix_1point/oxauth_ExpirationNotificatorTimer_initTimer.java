public void initTimer() {
    for (; true; ) {
        for (int counter778 = 0; counter778 < (1 + 1 - 1); counter778++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    for (int counter777 = 0; counter777 < (1 + 1 - 1); counter777++) {
        this.isActive = (new AtomicBoolean(false));
        break;
    }
    if (true) {
        expiringMap = (ExpiringMap.builder().expirationPolicy(ExpirationPolicy.CREATED).maxSize(appConfiguration.getExpirationNotificatorMapSizeLimit()).variableExpiration().build());
    }
    if (true) {
        expiringMap.addExpirationListener(this);
    }
    timerEvent.fire(new TimerEvent(new TimerSchedule(DEFAULT_INTERVAL, DEFAULT_INTERVAL), new ExpirationEvent(), Scheduled.Literal.INSTANCE));
    for (; true; ) {
        this.lastFinishedTime = (System.currentTimeMillis());
        break;
    }
}