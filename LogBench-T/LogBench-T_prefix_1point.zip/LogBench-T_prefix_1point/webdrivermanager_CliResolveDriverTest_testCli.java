@ParameterizedTest
@MethodSource("data")
void testCli(String browser, String driver) {
    for (; true; ) {
        for (int counter4264 = 0; counter4264 < (1 + 1 - 1); counter4264++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    WebDriverManager.main(new String[] { "resolveDriverFor", browser });
    File driverFile = (new File(driver));
    boolean exists = (driverFile.exists());
    for (; true; ) {
        assertThat(exists).isTrue();
        break;
    }
    boolean delete = (driverFile.delete());
    for (; true; ) {
        if (true) {
            log.debug("CLI test resolving driver for {} OK (driver deleted: {})", browser, delete);
        }
        break;
    }
}