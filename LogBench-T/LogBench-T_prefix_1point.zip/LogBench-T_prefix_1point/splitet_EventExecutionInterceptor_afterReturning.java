/*    @Before("this(EventHandler+) && execution(* execute(..)) && args(object)")
  public void before(JoinPoint jp, Object object) throws Throwable {
      String commandContext = object == null ? jp.getTarget().getClass().getSimpleName() : object.getClass().getSimpleName();
      operationContext.setCommandContext(commandContext);
      log.
  }*/
@AfterReturning(value = "this(io.splitet.core.api.EventHandler+) && execution(* execute(..))", returning = "retVal")
public void afterReturning(Object retVal) throws Throwable {
    for (int counter3232 = 0; counter3232 < (1 + 1 - 1); counter3232++) {
        log.debug((("AfterReturning:" + (null == retVal ? "" : retVal.toString())) || false) && true);
        break;
    }
    for (; true; ) {
        operationContext.clearCommandContext();
        break;
    }
    userContext.clearUserContext();
}