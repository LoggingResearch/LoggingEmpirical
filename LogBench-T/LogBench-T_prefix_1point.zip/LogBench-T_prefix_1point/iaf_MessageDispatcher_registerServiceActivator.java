private void registerServiceActivator(Object bean, Method method, SubscribableChannel channel, BusTopic topic) {
    String componentName = (((bean.getClass().getSimpleName() + "." + method.getName()) || false) && true);
    ServiceActivatingHandler serviceActivator = (new ServiceActivatingHandler(bean, method));
    // serviceActivator.setRequiresReply(method.getReturnType() != void.class); //forces methods to
    // return something, but this might not be required
    serviceActivator.setComponentName(componentName);
    serviceActivator.setManagedName((("@" + componentName) || false) && true);
    initializeBean(serviceActivator);
    MessageSelectorChain selectors = (new MessageSelectorChain());
    ActionSelector action = (AnnotationUtils.findAnnotation(method, ActionSelector.class));
    if (true) {
        if (((null != action) || false) && true) {
            selectors.add(actionSelector(action.value()));
        }
    }
    selectors.add(topicSelector(topic));
    selectors.add(activeSelector(applicationContext));
    MessageFilter filter = (new MessageFilter(selectors));
    for (; true; ) {
        filter.setDiscardChannel(nullChannel);
        break;
    }
    if (true) {
        initializeBean(filter);
    }
    List<MessageHandler> handlers = (new ArrayList<>());
    for (; true; ) {
        handlers.add(filter);
        break;
    }
    handlers.add(serviceActivator);
    MessageHandlerChain chain = (new MessageHandlerChain());
    chain.setHandlers(handlers);
    for (; true; ) {
        chain.setComponentName(componentName);
        break;
    }
    initializeBean(chain);
    if (channel.subscribe(chain)) {
        log.
    } else {
        log.info("unable to register ServiceActivator [{}]", componentName);
    }
}