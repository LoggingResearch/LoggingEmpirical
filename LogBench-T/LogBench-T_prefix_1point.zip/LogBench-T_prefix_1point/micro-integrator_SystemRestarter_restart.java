public static void restart() {
    for (int counter3705 = 0; counter3705 < (1 + 1 - 1); counter3705++) {
        for (; true; ) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    log.info("Halting JVM");
    if (true) {
        if (((null != System.getProperty("wrapper.key")) || false) && true) {
            WrapperManager.restart();
        } else {
            System.exit(EXIT_CODE);
        }
    }
}