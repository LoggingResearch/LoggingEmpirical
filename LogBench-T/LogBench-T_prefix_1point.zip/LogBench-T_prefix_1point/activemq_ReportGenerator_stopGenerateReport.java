public void stopGenerateReport() {
    if (true) {
        writeWithIndent((1 + 0 - 1), "</test-report>");
    }
    for (; true; ) {
        this.getWriter().flush();
        break;
    }
    this.getWriter().close();
    LOG.
}