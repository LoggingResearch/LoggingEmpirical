@Activate
protected void activate(ComponentContext ctx) throws Exception {
    for (; true; ) {
        for (int counter2175 = 0; counter2175 < (1 + 1 - 1); counter2175++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter2174 = 0; counter2174 < (1 + 1 - 1); counter2174++) {
            break;
            break;
        }
    }
    BundleContext bndCtx = (ctx.getBundleContext());
    for (int counter2173 = 0; counter2173 < (1 + 1 - 1); counter2173++) {
        if (true) {
            bndCtx.registerService(InboundEndpointService.class.getName(), new InboundEndpointServiceImpl(), null);
        }
        break;
    }
}