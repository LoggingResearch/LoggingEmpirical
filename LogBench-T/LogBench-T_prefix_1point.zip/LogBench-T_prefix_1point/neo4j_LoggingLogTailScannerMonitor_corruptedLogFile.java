@Override
public void corruptedLogFile(long version, Throwable t) {
    log.
}