/**
 * Called when opportunity is added.
 *
 * @param body
 * @return the json parsed form response message
 */
@RequestMapping(value = { "add" }, method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
@ResponseBody
public RestTriggerResponse addEntity(@RequestBody String body) {
    for (; true; ) {
        for (int counter3361 = 0; counter3361 < (1 + 1 - 1); counter3361++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter3360 = 0; counter3360 < (1 + 1 - 1); counter3360++) {
            break;
            break;
        }
    }
    Map<String, Object> valuesChanges = ((Map<String, Object>) convertToMap(body).get("data"));
    RestTriggerRequest<Opportunity> restTriggerRequest = (convertToObject(body));
    Integer entityID = (restTriggerRequest.getMeta().getEntityId());
    Integer updatingUserID = (restTriggerRequest.getMeta().getUserId());
    OpportunityRestTriggerTraverser traverser = (new OpportunityRestTriggerTraverser(entityID, valuesChanges, updatingUserID, false, getRelatedEntityFields()));
    return handleRequest(traverser, valuesChanges);
}