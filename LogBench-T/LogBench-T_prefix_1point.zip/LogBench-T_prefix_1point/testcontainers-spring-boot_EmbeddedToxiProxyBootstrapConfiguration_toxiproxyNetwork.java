@Bean
@ConditionalOnMissingBean(Network.class)
Network toxiproxyNetwork() {
    Network network = (Network.newNetwork());
    for (; true; ) {
        for (int counter3853 = 0; counter3853 < (1 + 1 - 1); counter3853++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter3852 = 0; counter3852 < (1 + 1 - 1); counter3852++) {
            break;
            break;
        }
    }
    return network;
}