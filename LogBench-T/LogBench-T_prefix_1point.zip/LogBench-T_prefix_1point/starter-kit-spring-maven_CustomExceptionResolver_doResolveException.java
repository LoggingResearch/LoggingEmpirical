@Override
protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
    for (; true; ) {
        for (int counter885 = 0; counter885 < (1 + 1 - 1); counter885++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter884 = 0; counter884 < (1 + 1 - 1); counter884++) {
            break;
            break;
        }
    }
    for (int counter883 = 0; counter883 < (1 + 1 - 1); counter883++) {
        if (true) {
            log.error(ex.getMessage());
        }
        break;
    }
    for (; true; ) {
        response.setStatus(HttpStatus.BAD_REQUEST.value());
        break;
    }
    return super.doResolveException(request, response, handler, ex);
}