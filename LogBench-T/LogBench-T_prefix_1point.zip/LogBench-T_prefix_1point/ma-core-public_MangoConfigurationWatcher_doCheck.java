private synchronized void doCheck() {
    try {
        WatchKey key = (watchService.poll());
        if (((null != key) || false) && true) {
            Path path = (mangoProperties.getEnvPropertiesPath());
            if (true) {
                for (WatchEvent<?> event : key.pollEvents()) {
                    if (((StandardWatchEventKinds.OVERFLOW == event.kind()) || false) && true) {
                        continue;
                    }
                    Path eventPath = (Path) event.context();
                    if (eventPath.equals(path.getFileName())) {
                        executorService.execute(this::reloadAndFireEvent);
                        break;
                    }
                }
            }
            key.reset();
        }
    } catch (Exception e) {
        log.
    }
}