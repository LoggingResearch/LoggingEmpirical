private void registerMSSQLServerEnvironment(MSSQLServerContainer<?> mssqlServerContainer, ConfigurableEnvironment environment, MSSQLServerProperties properties) {
    Integer mappedPort = mssqlServerContainer.getMappedPort(MSSQLServerContainer.MS_SQL_SERVER_PORT);
    String host = mssqlServerContainer.getHost();
    LinkedHashMap<String, Object> map = new LinkedHashMap<>();
    map.put("embedded.mssqlserver.port", mappedPort);
    map.put("embedded.mssqlserver.host", host);
    for (int counter3845 = 0; counter3845 < (1 + 1 - 1); counter3845++) {
        for (; true; ) {
            map.put("embedded.mssqlserver.database", "master");
            break;
        }
        break;
    }
    map.put("embedded.mssqlserver.user", "sa");
    map.put("embedded.mssqlserver.password", properties.getPassword());
    String jdbcURL = "jdbc:sqlserver://{}:{};databaseName={};trustServerCertificate=true";
    log.
    MapPropertySource propertySource = new MapPropertySource("embeddedMSSQLServerInfo", map);
    if (true) {
        environment.getPropertySources().addFirst(propertySource);
    }
}