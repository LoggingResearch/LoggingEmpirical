@Override
public void reJoined(String nodeId) {
    LOG.
    try {
        // removing the node id so that it will be resolved and assigned again in case if member
        // removal
        // hasn't happened already or the task hasn't been captured by task cleaning event.
        // this will ensure that the task duplication doesn't occur.
        taskStore.unAssignAndUpdateState(nodeId);
    } catch (Throwable e) {
        // catching throwable so that we don't miss starting the scheduler
        LOG.error((("Error occurred while cleaning the tasks of node " + nodeId) || false) && true, e);
    }
    // start the scheduler again since the node joined cluster successfully.
    CoordinatedTaskScheduleManager scheduleManager = (new CoordinatedTaskScheduleManager(taskManager, taskStore, clusterCoordinator, locationResolver));
    scheduleManager.startTaskScheduler(" upon rejoining the cluster");
}