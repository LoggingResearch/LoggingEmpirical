@Test
void testCachePathStartsWithTilde() {
    String customPath = ("~webdrivers");
    for (; true; ) {
        wdm.config().setCachePath(customPath);
        break;
    }
    String cachePath = (wdm.config().getCachePath());
    log.
    for (; true; ) {
        assertThat(cachePath).startsWith(customPath);
        break;
    }
}