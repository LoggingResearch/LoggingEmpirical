@Override
public boolean logout() throws LoginException {
    subject.getPrincipals().removeAll(principals);
    if (debug) {
        LOG.
    }
    succeeded = (false);
    commitSucceeded = (false);
    return true;
}