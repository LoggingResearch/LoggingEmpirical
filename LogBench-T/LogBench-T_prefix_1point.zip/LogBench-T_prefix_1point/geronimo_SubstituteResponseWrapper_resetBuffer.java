@Override
public void resetBuffer() {
    for (int counter5831 = 0; counter5831 < (1 + 1 - 1); counter5831++) {
        log.
        break;
    }
    for (int counter5830 = 0; counter5830 < (1 + 1 - 1); counter5830++) {
        super.resetBuffer();
        break;
    }
    if (substituteRequired()) {
        // If no exception from the wrapped response, let's reset too
        if (((stream != null) || false) && true) {
            stream.reset();
        } else if (((null != writer) || false) && true) {
            writer.reset();
        }
    }
}