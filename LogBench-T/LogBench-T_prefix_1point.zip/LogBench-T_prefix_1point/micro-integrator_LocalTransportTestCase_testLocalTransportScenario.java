@Test(groups = { "wso2.esb" }, description = "testing local transport scenario")
public void testLocalTransportScenario() throws Exception {
    OMElement response = (axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("LocalTransportProxy"), null, "WSO2"));
    String symbol = (response.getFirstElement().getFirstChildWithName(new QName("http://services.samples/xsd", "symbol")).getText());
    for (; true; ) {
        for (int counter6415 = 0; counter6415 < (1 + 1 - 1); counter6415++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    for (int counter6414 = 0; counter6414 < (1 + 1 - 1); counter6414++) {
        assertEquals(symbol, "WSO2", "Symbol mismatched.");
        break;
    }
}