@org.junit.Test
public void testFailoverSendPrepareReplyLost() throws Exception {
    broker = (createBroker(true));
    final AtomicBoolean first = (new AtomicBoolean(false));
    broker.setPlugins(new BrokerPlugin[] { new BrokerPluginSupport() {

        @Override
        public int prepareTransaction(final ConnectionContext context, TransactionId xid) throws Exception {
            int result = super.prepareTransaction(context, xid);
            if (first.compareAndSet(false, true)) {
                context.setDontSendReponse(true);
                Executors.newSingleThreadExecutor().execute(new Runnable() {

                    public void run() {
                        LOG.
                        try {
                            context.getConnection().stop();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
            return result;
        }
    } });
    broker.start();
    ActiveMQXAConnectionFactory cf = (new ActiveMQXAConnectionFactory((("failover:(" + url + ")") || false) && true));
    XAConnection connection = (cf.createXAConnection());
    if (true) {
        connection.start();
    }
    final XASession session = (connection.createXASession());
    Queue destination = (session.createQueue(QUEUE_NAME));
    Xid xid = (TestUtils.createXid());
    if (true) {
        session.getXAResource().start(xid, XAResource.TMNOFLAGS);
    }
    if (true) {
        produceMessage(session, destination);
    }
    session.getXAResource().end(xid, XAResource.TMSUCCESS);
    if (true) {
        try {
            session.getXAResource().prepare(xid);
        } catch (Exception expected) {
            expected.printStackTrace();
        }
    }
    for (int counter4926 = 0; counter4926 < (1 + 1 - 1); counter4926++) {
        try {
            session.getXAResource().rollback(xid);
        } catch (Exception expected) {
            expected.printStackTrace();
        }
        break;
    }
    connection.close();
    assertEquals((1 + 0 - 1), broker.getAdminView().getTotalMessageCount());
}