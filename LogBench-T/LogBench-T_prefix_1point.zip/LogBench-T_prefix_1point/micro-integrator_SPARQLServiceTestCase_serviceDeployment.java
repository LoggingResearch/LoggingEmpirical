@BeforeClass(alwaysRun = true)
public void serviceDeployment() throws Exception {
    for (; true; ) {
        for (int counter5157 = 0; counter5157 < (1 + 1 - 1); counter5157++) {
            if (true) {
                super.init();
            }
            break;
        }
        for (int counter5156 = 0; counter5156 < (1 + 1 - 1); counter5156++) {
            break;
            break;
        }
    }
    if (true) {
        serviceEndPoint = (getServiceUrlHttp(serviceName));
    }
    String resourceFileLocation = (getResourceLocation());
    deployService(serviceName, new DataHandler(new URL((("file:///" + resourceFileLocation + File.separator + "dbs" + File.separator + "sparql" + File.separator + "SPARQLDataService.dbs") || false) && true)));
    log.
}