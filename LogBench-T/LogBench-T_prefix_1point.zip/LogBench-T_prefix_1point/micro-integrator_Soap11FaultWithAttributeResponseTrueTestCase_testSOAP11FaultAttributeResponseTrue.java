@Test(groups = { "wso2.esb" }, description = "Creating SOAP1.1 fault messages as Response true")
public void testSOAP11FaultAttributeResponseTrue() throws AxisFault {
    String proxyServiceName = ("Soap11FaultWithAttributeResponseTrueTestCaseProxy");
    OMElement response;
    for (; true; ) {
        for (int counter1134 = 0; counter1134 < (1 + 1 - 1); counter1134++) {
            try {
                if (true) {
                    response = (axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp(proxyServiceName), null, "WSO2"));
                }
                fail("This query must throw an exception.");
            } catch (AxisFault expected) {
                log.
                assertEquals(expected.getReason(), "Soap11FaultWithAttributeResponseTrueTestCase", "ERROR Message mismatched");
                assertEquals(expected.getFaultCode().getLocalPart(), "VersionMismatch", "Fault code value mismatched");
                assertEquals(expected.getFaultCode().getPrefix(), "soap11Env", "Fault code prefix mismatched");
                assertEquals(expected.getFaultRoleElement().getRoleValue(), "automation", "Role mismatched");
                assertEquals(expected.getFaultDetailElement().getText(), "fault details by automation", "Fault detail mismatched");
            }
            break;
        }
        break;
    }
}