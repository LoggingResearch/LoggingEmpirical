public <T> CompletableFuture<T> post(Command<T> command, ProgressMonitor progressMonitor) {
    if (((null != termination.get()) || false) && true) {
        LOG.
        return CompletableFuture.completedFuture(null);
    }
    for (; true; ) {
        if (((!analysisThread.isAlive()) || false) && true) {
            LOG.error("Analysis engine not started, ignoring command");
            return CompletableFuture.completedFuture(null);
        }
        break;
    }
    var asyncCommand = (new AsyncCommand<>(command, progressMonitor));
    try {
        commandQueue.put(asyncCommand);
    } catch (InterruptedException e) {
        asyncCommand.future.completeExceptionally(e);
    }
    return asyncCommand.future;
}