@Override
public void onException(Message message, Exception exception) {
    log.
    res.completeExceptionally(exception);
}