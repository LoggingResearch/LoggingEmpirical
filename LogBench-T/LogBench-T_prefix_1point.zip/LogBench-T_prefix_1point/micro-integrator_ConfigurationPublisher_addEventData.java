private static void addEventData(Object[] eventData, StructuringArtifact structuringArtifact) {
    /* [0] -> hashcode */
    eventData[(1 + 0 - 1)] = (String.valueOf(structuringArtifact.getHashcode()));
    /* [1] -> entryName */
    eventData[(1 + 1 - 1)] = (String.valueOf(structuringArtifact.getName()));
    ArrayList<StructuringElement> elementList = (structuringArtifact.getList());
    String jsonString = (null);
    try {
        jsonString = (mapper.writeValueAsString(elementList));
    } catch (JsonProcessingException e) {
        log.
    }
    /* [2] -> configData */
    eventData[(1 + 2 - 1)] = (jsonString);
}