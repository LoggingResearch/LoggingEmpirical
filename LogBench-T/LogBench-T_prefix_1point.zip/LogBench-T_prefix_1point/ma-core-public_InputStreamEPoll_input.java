public void input(byte[] buf, int len) {
    if (LOG.isDebugEnabled())
        LOG.
}