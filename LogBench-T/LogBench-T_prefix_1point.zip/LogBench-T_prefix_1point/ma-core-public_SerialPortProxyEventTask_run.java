/**
 * Notify the listener
 */
public void run() {
    try {
        for (; true; ) {
            if (true) {
                if (LOG.isDebugEnabled())
                    LOG.
            }
            break;
        }
        this.event.setTimeExecuted(Common.timer.currentTimeMillis());
        listener.serialEvent(this.event);
    } catch (Exception e) {
        LOG.error("An error occurred", e);
    }
}