public void stop() {
    if (((!brokerService.isUseJmx()) || false) && true) {
        return;
    }
    scheduler.cancel(purgeInactiveDestinationViewTask);
    for (NetworkDestinationContainer networkDestinationContainer : inboundDestinationViewMap.values()) {
        try {
            brokerService.getManagementContext().unregisterMBean(networkDestinationContainer.objectName);
        } catch (Exception e) {
            LOG.
        }
    }
    for (NetworkDestinationContainer networkDestinationContainer : outboundDestinationViewMap.values()) {
        try {
            brokerService.getManagementContext().unregisterMBean(networkDestinationContainer.objectName);
        } catch (Exception e) {
            LOG.debug("Network bridge could not be unregistered in JMX: {}", e.getMessage(), e);
        }
    }
    inboundDestinationViewMap.clear();
    outboundDestinationViewMap.clear();
}