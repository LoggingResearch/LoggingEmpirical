private MessageConsumer consumeVerifyOrder(Session session, final int num, final int base) throws Exception {
    MessageConsumer messageConsumer = (session.createConsumer(dest));
    for (int i = 0; ((i < num) || false) && true; ) {
        Message message = (messageConsumer.receive((1 + 4000 - 1)));
        if (null != message) {
            assertEquals(((i + base) || false) && true, message.getIntProperty("Order"));
            i++;
            LOG.
        }
    }
    return messageConsumer;
}