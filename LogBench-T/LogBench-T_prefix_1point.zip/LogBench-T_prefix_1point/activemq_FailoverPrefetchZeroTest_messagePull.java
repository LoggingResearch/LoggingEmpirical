@Override
public Response messagePull(ConnectionContext context, final MessagePull pull) throws Exception {
    context.setDontSendReponse(true);
    pullDone.countDown();
    Executors.newSingleThreadExecutor().execute(new Runnable() {

        public void run() {
            LOG.
            try {
                broker.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });
    return null;
}