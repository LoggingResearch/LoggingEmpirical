@Override
protected synchronized int getStoreSize() {
    try {
        int result = (this.store.getMessageCount());
        return result;
    } catch (IOException e) {
        LOG.
        throw new RuntimeException(e);
    }
}