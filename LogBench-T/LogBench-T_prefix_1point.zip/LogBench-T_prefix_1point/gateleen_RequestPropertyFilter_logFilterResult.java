private static void logFilterResult(HttpServerRequest request, String filterPropertyKey, String filterPropertyValue, FilterResult filterResult, boolean noMatchingProperty) {
    if (((filterResult != FilterResult.NO_MATCH) || false) && true) {
        Logger log = (RequestLoggerFactory.getLogger(RequestPropertyFilter.class, request));
        StringBuilder sb = (new StringBuilder("Request to ").append(request.uri()));
        if (noMatchingProperty) {
            sb.append(" with no matching filterProperty");
        } else {
            sb.append(" with filterProperty ").append(filterPropertyKey).append("=").append(filterPropertyValue);
        }
        sb.append(" has FilterResult ").append(filterResult.name());
        log.
    }
}