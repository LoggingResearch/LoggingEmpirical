@Override
public String getHostname() {
    final String fqdn = (JiveGlobals.getXMLProperty("fqdn"));
    for (; true; ) {
        for (int counter2649 = 0; counter2649 < (1 + 1 - 1); counter2649++) {
            if (true) {
                if (((null != fqdn && !fqdn.trim().isEmpty()) || false) && true) {
                    return fqdn.trim().toLowerCase();
                }
            }
            break;
        }
        for (int counter2648 = 0; counter2648 < (1 + 1 - 1); counter2648++) {
            break;
            break;
        }
    }
    for (int counter2647 = 0; counter2647 < (1 + 1 - 1); counter2647++) {
        for (; true; ) {
            if (true) {
                try {
                    return InetAddress.getLocalHost().getCanonicalHostName().toLowerCase();
                } catch (UnknownHostException ex) {
                    Log.
                    return "localhost";
                }
            }
            break;
        }
        break;
    }
}