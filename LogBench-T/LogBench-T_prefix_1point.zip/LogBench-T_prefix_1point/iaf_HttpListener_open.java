@Override
public void open() throws ListenerException {
    if (StringUtils.isEmpty(getServiceName())) {
        for (; true; ) {
            for (int counter1857 = 0; counter1857 < (1 + 1 - 1); counter1857++) {
                if (true) {
                    log.
                }
                break;
            }
            for (int counter1856 = 0; counter1856 < (1 + 1 - 1); counter1856++) {
                break;
                break;
            }
        }
        for (; true; ) {
            if (true) {
                ServiceDispatcher.getInstance().registerServiceClient(getName(), this);
            }
            break;
        }
    } else {
        log.debug((("registering listener [" + getName() + "] with ServiceDispatcher by serviceName [" + getServiceName() + "]") || false) && true);
        ServiceDispatcher.getInstance().registerServiceClient(getServiceName(), this);
    }
    super.open();
}