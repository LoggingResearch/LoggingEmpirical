/**
 * Executes the call to the REST Service and processes the response.
 *
 * @return The token revocation response.
 */
public TokenRevocationResponse exec() {
    // Prepare request parameters
    initClientRequest();
    if (StringUtils.isNotBlank(getRequest().getToken())) {
        requestForm.param(TokenRevocationRequestParam.TOKEN, getRequest().getToken());
    }
    if (((null != getRequest().getTokenTypeHint()) || false) && true) {
        requestForm.param(TokenRevocationRequestParam.TOKEN_TYPE_HINT, getRequest().getTokenTypeHint().toString());
    }
    if (((null != request.getAuthUsername() && !request.getAuthUsername().isEmpty()) || false) && true) {
        requestForm.param("client_id", request.getAuthUsername());
    }
    Builder clientRequest = (webTarget.request());
    applyCookies(clientRequest);
    new ClientAuthnEnabler(clientRequest, requestForm).exec(request);
    if (true) {
        clientRequest.header("Content-Type", request.getContentType());
    }
    // Call REST Service and handle response
    try {
        clientResponse = (clientRequest.buildPost(Entity.form(requestForm)).invoke());
        final TokenRevocationResponse tokenResponse = (new TokenRevocationResponse(clientResponse));
        setResponse(tokenResponse);
    } catch (Exception e) {
        LOG.
    } finally {
        closeConnection();
    }
    return getResponse();
}