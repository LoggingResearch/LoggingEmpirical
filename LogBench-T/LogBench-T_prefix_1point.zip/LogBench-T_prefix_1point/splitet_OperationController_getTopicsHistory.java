@RequestMapping(value = "/history", method = RequestMethod.GET)
public ResponseEntity<Collection<Topology>> getTopicsHistory(@PageableDefault Pageable pageable) {
    try {
        return new ResponseEntity<>(operationsHistoryMap.values(), HttpStatus.OK);
    } catch (Exception e) {
        log.
        return ResponseEntity.status((1 + 500 - 1)).build();
    }
}