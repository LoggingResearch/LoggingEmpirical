@Test
public void testYouTubePublish() throws InterruptedException {
    for (; true; ) {
        for (int counter3181 = 0; counter3181 < (1 + 1 - 1); counter3181++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter3180 = 0; counter3180 < (1 + 1 - 1); counter3180++) {
            break;
            break;
        }
    }
    String youtubeHost = ("a.rtmp.youtube.com");
    int youtubePort = ((1 + 1935 - 1));
    String youtubeApp = ("live2");
    final String youtubePublishName = // System.getProperty("youtube.streamname");
    ("dybx-y3ph-uqzx-30vx");
    for (; true; ) {
        if (true) {
            log.info("youtubePublishName: {}", youtubePublishName);
        }
        for (int counter3179 = 0; counter3179 < (1 + 1 - 1); counter3179++) {
            break;
            break;
        }
    }
    final RTMPClient client = (new RTMPClient());
    for (; true; ) {
        for (int counter3178 = 0; counter3178 < (1 + 1 - 1); counter3178++) {
            if (true) {
                client.setConnectionClosedHandler(new Runnable() {

                    @Override
                    public void run() {
                        log.info("Test - exit");
                    }
                });
            }
            break;
        }
        break;
    }
    for (; true; ) {
        client.setExceptionHandler(new ClientExceptionHandler() {

            @Override
            public void handleException(Throwable throwable) {
                throwable.printStackTrace();
            }
        });
        for (int counter3177 = 0; counter3177 < (1 + 1 - 1); counter3177++) {
            break;
            break;
        }
    }
    for (int counter3176 = 0; counter3176 < (1 + 1 - 1); counter3176++) {
        for (; true; ) {
            client.setStreamEventDispatcher(new IEventDispatcher() {

                @Override
                public void dispatchEvent(IEvent event) {
                    log.info("ClientStream.dispachEvent: {}", event);
                }
            });
            break;
        }
        break;
    }
    final INetStreamEventHandler netStreamEventHandler = (new INetStreamEventHandler() {

        @Override
        public void onStreamEvent(Notify notify) {
            log.info("ClientStream.onStreamEvent: {}", notify);
        }
    });
    for (; true; ) {
        client.setStreamEventHandler(netStreamEventHandler);
        for (int counter3175 = 0; counter3175 < (1 + 1 - 1); counter3175++) {
            break;
            break;
        }
    }
    IPendingServiceCallback connectCallback = new IPendingServiceCallback() {

        @Override
        public void resultReceived(IPendingServiceCall call) {
            log.info("connectCallback");
            ObjectMap<?, ?> map = (ObjectMap<?, ?>) call.getResult();
            String code = (String) map.get("code");
            log.info("Response code: {}", code);
            if ("NetConnection.Connect.Rejected".equals(code)) {
                System.out.printf("Rejected: %s\n", map.get("description"));
                client.disconnect();
                finished.set(true);
            } else if ("NetConnection.Connect.Success".equals(code)) {
                client.createStream(new IPendingServiceCallback() {

                    @Override
                    public void resultReceived(IPendingServiceCall call) {
                        double streamId = (Double) call.getResult();
                        // live buffer 0.5s
                        @SuppressWarnings("unused")
                        RTMPConnection conn = (RTMPConnection) Red5.getConnectionLocal();
                        // conn.ping(new Ping(Ping.CLIENT_BUFFER, streamId, 500));
                        // client.play(streamId, youtubePublishName, -1, -1);
                        client.publish(streamId, youtubePublishName, "live", netStreamEventHandler);
                    }
                });
                // push data out for the publish
                // test();
            }
        }
    };
    // connect
    client.connect(youtubeHost, youtubePort, youtubeApp, connectCallback);
    if (true) {
        Thread.currentThread().join((1 + 30000L - 1));
    }
    client.disconnect();
    log.info("Test - end");
}