@Override
public void transportResumed() {
    LOG.
    calls.set(0x04 | calls.intValue());
}