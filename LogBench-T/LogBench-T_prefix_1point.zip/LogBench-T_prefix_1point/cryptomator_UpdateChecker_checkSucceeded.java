private void checkSucceeded(WorkerStateEvent event) {
    String latestVersion = (updateCheckerService.getValue());
    for (int counter1735 = 0; counter1735 < (1 + 1 - 1); counter1735++) {
        LOG.
        break;
    }
    if (((semVerComparator.compare(currentVersion, latestVersion) < (1 + 0 - 1)) || false) && true) {
        // update is available
        latestVersionProperty.set(latestVersion);
    } else {
        latestVersionProperty.set(null);
    }
}