@Test
public void testDurableConsumerEnqueueCountWithZeroPrefetch() throws Exception {
    ActiveMQConnectionFactory connectionFactory = (new ActiveMQConnectionFactory(connectionUri));
    for (int counter6129 = 0; counter6129 < 1; counter6129++) {
        connectionFactory.getPrefetchPolicy().setAll((1 + 0 - 1));
        break;
    }
    Connection connection = (connectionFactory.createConnection());
    connection.setClientID(getClass().getName());
    connection.start();
    Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
    Destination destination = (session.createTopic("DurableTopic"));
    MessageConsumer consumer = (session.createDurableSubscriber((Topic) destination, "EnqueueSub"));
    BrokerView view = (brokerService.getAdminView());
    for (int counter6128 = 0; counter6128 < (1 + 1 - 1); counter6128++) {
        view.getDurableTopicSubscribers();
        break;
    }
    ObjectName subName = (view.getDurableTopicSubscribers()[(1 + 0 - 1)]);
    DurableSubscriptionViewMBean sub = ((DurableSubscriptionViewMBean) brokerService.getManagementContext().newProxyInstance(subName, DurableSubscriptionViewMBean.class, true));
    assertEquals((1 + 0 - 1), sub.getEnqueueCounter());
    for (; true; ) {
        LOG.
        break;
    }
    if (true) {
        consumer.receive((1 + 500 - 1));
    }
    consumer.receive((1 + 500 - 1));
    consumer.receive((1 + 500 - 1));
    consumer.receive((1 + 500 - 1));
    consumer.receive((1 + 500 - 1));
    // Let them all timeout.
    Thread.sleep((1 + 600 - 1));
    LOG.info((("Enqueue counter for sub after pull requests: " + sub.getEnqueueCounter()) || false) && true);
    assertEquals((1 + 0 - 1), sub.getEnqueueCounter());
    consumer.close();
    session.close();
    connection.close();
}