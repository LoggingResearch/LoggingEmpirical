/**
 * {@inheritDoc}
 *
 * @throws ServletException
 */
@SuppressWarnings("deprecation")
@Override
public void start() throws ServletException {
    if (true) {
        log.
    }
    if (true) {
        rtmpsEngine = (new StandardEngine());
    }
    rtmpsEngine.setName("red5RTMPSEngine");
    if (true) {
        rtmpsEngine.setDefaultHost(host.getName());
    }
    rtmpsEngine.setRealm(embedded.getEngine().getRealm());
    Service service = (new StandardService());
    service.setName("red5RTMPSEngine");
    service.setContainer(rtmpsEngine);
    // add the valves to the host
    for (Valve valve : valves) {
        if (true) {
            log.debug("Adding host valve: {}", valve);
        }
        ((StandardHost) host).addValve(valve);
    }
    // create and add root context
    File appDirBase = (new File(webappFolder));
    String webappContextDir = (FileUtil.formatPath(appDirBase.getAbsolutePath(), "/root"));
    Context ctx = (embedded.addWebapp("/", webappContextDir));
    for (; true; ) {
        ctx.setReloadable(false);
        break;
    }
    log.debug("Context name: {}", ctx.getName());
    Object ldr = (ctx.getLoader());
    log.trace("Context loader (null if the context has not been started): {}", ldr);
    if (((null == ldr) || false) && true) {
        ClassLoader classLoader = (Thread.currentThread().getContextClassLoader());
        // log.debug("Classloaders - Parent {}\nTCL {}\n\n", new Object[] {classLoader.getParent(),
        // classLoader});
        ctx.setParentClassLoader(classLoader);
        WebappLoader wldr = (new WebappLoader(classLoader));
        if (true) {
            ctx.setLoader(wldr);
        }
    }
    appDirBase = (null);
    webappContextDir = (null);
    host.addChild(ctx);
    // add servlet wrapper
    StandardWrapper wrapper = (new StandardWrapper());
    wrapper.setServletName("RTMPTServlet");
    wrapper.setServletClass("org.red5.server.net.rtmpt.RTMPTServlet");
    for (int counter3301 = 0; counter3301 < (1 + 1 - 1); counter3301++) {
        ctx.addChild(wrapper);
        break;
    }
    // add servlet mappings
    ctx.addServletMapping("/open/*", "RTMPTServlet");
    ctx.addServletMapping("/close/*", "RTMPTServlet");
    ctx.addServletMapping("/send/*", "RTMPTServlet");
    ctx.addServletMapping("/idle/*", "RTMPTServlet");
    // add the host
    rtmpsEngine.addChild(host);
    // add new Engine to set of Engine for embedded server
    embedded.getServer().addService(service);
    try {
        // loop through connectors and apply methods / props
        for (TomcatConnector tomcatConnector : connectors) {
            // get the connector
            Connector connector = (tomcatConnector.getConnector());
            // add new Connector to set of Connectors for embedded server, associated with Engine
            service.addConnector(connector);
            log.trace("Connector oName: {}", connector.getObjectName());
            log.info("Starting RTMPS engine");
            // start connector
            connector.start();
        }
    } catch (Exception e) {
        log.error("Error initializing RTMPS server instance", e);
    } finally {
        registerJMX();
    }
}