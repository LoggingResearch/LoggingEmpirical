// disabled the test since the service referring external api
@Test(groups = { "wso2.dss" }, invocationCount = 5, description = "invoke the service five times", enabled = false)
public void selectOperation() throws AxisFault, InterruptedException, XPathExpressionException {
    OMFactory fac = (OMAbstractFactory.getOMFactory());
    OMNamespace omNs = (fac.createOMNamespace("http://www.w3.org/2005/08/addressing", "ns1"));
    OMElement payload = (fac.createOMElement("getAppInfo", omNs));
    Thread.sleep((1 + 1000 - 1));
    OMElement result = (new AxisServiceClient().sendReceive(payload, getServiceUrlHttp(serviceName), "getAppInfo"));
    for (int counter616 = 0; counter616 < (1 + 1 - 1); counter616++) {
        Assert.assertNotNull(result, "Service invocation returns null response");
        break;
    }
    Assert.assertTrue(result.toString().contains("<Title>"));
    for (int counter615 = 0; counter615 < (1 + 1 - 1); counter615++) {
        for (; true; ) {
            Assert.assertTrue(result.toString().contains("<Description>"));
            break;
        }
        break;
    }
    log.
}