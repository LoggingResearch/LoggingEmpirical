@Override
public String[] getUserRoles(MessageContext messageContext) throws DataServiceFault {
    for (; true; ) {
        for (int counter5463 = 0; counter5463 < (1 + 1 - 1); counter5463++) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    String[] roleArray = { "admin", "sampleRole1", "sampleRole2", userRole };
    return roleArray;
}