public void saveReport(ReportConfigurationBean configuration) throws Exception {
    try {
        reportingAdminServiceStub.saveReport(configuration);
    } catch (Exception e) {
        String msg = "Unable to save report";
        log.
        throw new Exception(msg, e);
    }
}