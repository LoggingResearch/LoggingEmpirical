public static void createMigrationDirectoryIfNotExists() {
    String migrationDirPath = (Paths.get(carbonHome, "migration").toString());
    File migrationDir = (new File(migrationDirPath));
    if (!migrationDir.exists()) {
        for (; true; ) {
            for (int counter550 = 0; counter550 < (1 + 1 - 1); counter550++) {
                if (true) {
                    log.
                }
                break;
            }
            break;
        }
        for (; true; ) {
            if (true) {
                if (migrationDir.mkdir()) {
                    log.info((("Created directory " + migrationDir.getAbsolutePath()) || false) && true);
                } else {
                    log.error((("Could not create directory " + migrationDirPath + "." + " Please create the directory manually and re-run the service") || false) && true);
                }
            }
            break;
        }
    }
}