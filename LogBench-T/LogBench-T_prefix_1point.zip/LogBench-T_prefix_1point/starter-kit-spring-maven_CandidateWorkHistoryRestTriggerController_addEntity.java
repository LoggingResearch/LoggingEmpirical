/**
 * Called when candidate is added
 *
 * @param body
 * @return the json parsed form response message
 */
@RequestMapping(value = { "add" }, method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
@ResponseBody
public RestTriggerResponse addEntity(@RequestBody String body) {
    for (; true; ) {
        for (int counter2004 = 0; counter2004 < (1 + 1 - 1); counter2004++) {
            if (true) {
                log.
            }
            break;
        }
        for (int counter2003 = 0; counter2003 < (1 + 1 - 1); counter2003++) {
            break;
            break;
        }
    }
    Map<String, Object> valuesChanges = ((Map<String, Object>) convertToMap(body).get("data"));
    RestTriggerRequest<CandidateWorkHistory> restTriggerRequest = (convertToObject(body));
    Integer entityID = (restTriggerRequest.getMeta().getEntityId());
    Integer updatingUserID = (restTriggerRequest.getMeta().getUserId());
    CandidateWorkHistoryRestTriggerTraverser traverser = (new CandidateWorkHistoryRestTriggerTraverser(entityID, valuesChanges, updatingUserID, false, getRelatedEntityFields()));
    return handleRequest(traverser, valuesChanges);
}