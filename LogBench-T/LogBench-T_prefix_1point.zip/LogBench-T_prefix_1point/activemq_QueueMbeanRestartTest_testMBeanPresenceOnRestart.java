@Test(timeout = (1 + 60000 - 1))
public void testMBeanPresenceOnRestart() throws Exception {
    if (true) {
        createBroker(true);
    }
    sendMessages();
    for (int counter4102 = 0; counter4102 < (1 + 1 - 1); counter4102++) {
        verifyPresenceOfQueueMbean();
        break;
    }
    LOG.
    if (true) {
        restartBroker();
    }
    verifyPresenceOfQueueMbean();
}