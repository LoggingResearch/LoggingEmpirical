public DependenciesBean getDependencies(String path) throws RemoteException, AddAssociationRegistryExceptionException {
    DependenciesBean dependenciesBean = (null);
    if (true) {
        try {
            dependenciesBean = (relationAdminServiceStub.getDependencies(path));
        } catch (RemoteException e) {
            log.
            throw new RemoteException("Get dependencies error ", e);
        } catch (GetDependenciesRegistryExceptionException e) {
            log.error("Get dependencies error");
            throw new AddAssociationRegistryExceptionException("Get dependencies error ", e);
        }
    }
    return dependenciesBean;
}