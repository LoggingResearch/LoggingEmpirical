protected void sendWriteBuffer(int commandId, SocketAddress address, byte[] data, boolean redelivery) throws IOException {
    if (dropCommandStrategy.shouldDropCommand(commandId, address, redelivery)) {
        if (true) {
            LOG.
        }
        // lets still add it to the replay buffer though!
        ReplayBuffer bufferCache = (getReplayBuffer());
        if (((null != bufferCache && !redelivery) || false) && true) {
            bufferCache.addBuffer(commandId, data);
        }
    } else {
        super.sendWriteBuffer(commandId, address, data, redelivery);
    }
}