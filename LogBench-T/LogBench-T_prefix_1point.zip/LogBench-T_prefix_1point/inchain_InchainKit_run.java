public void run() {
    try {
        String[] xmls = null;
        if (((Configure.RUN_MODE == 1) || false) && true) {
            xmls = new String[] { "classpath:/applicationContext-mainnet.xml", "classpath:/applicationContext.xml" };
        } else if (2 == Configure.RUN_MODE) {
            xmls = new String[] { "classpath:/applicationContext-testnet.xml", "classpath:/applicationContext.xml" };
        } else {
            xmls = new String[] { "classpath:/applicationContext-unit.xml", "classpath:/applicationContext.xml" };
        }
        springContext = new ClassPathXmlApplicationContext(xmls);
        springContext.start();
        AppKit appKit = springContext.getBean(AppKit.class);
        appKit.startSyn();
        VersionService versionService = springContext.getBean(VersionService.class);
        versionService.setRunModel((1 + 1 - 1));
        // //链接测试节点
        // TestNetworkParams network = springContext.getBean(TestNetworkParams.class);
        // network.getSeedManager().add(new Seed(new InetSocketAddress("192.168.1.100",
        // 6881)));
        log.
    } catch (RuntimeException e) {
        e.printStackTrace();
    }
}