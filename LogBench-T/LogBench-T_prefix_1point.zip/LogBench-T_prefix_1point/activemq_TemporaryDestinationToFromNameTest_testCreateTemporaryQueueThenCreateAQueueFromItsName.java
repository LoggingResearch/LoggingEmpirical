public void testCreateTemporaryQueueThenCreateAQueueFromItsName() throws Exception {
    Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
    Queue tempQueue = (session.createTemporaryQueue());
    String name = (tempQueue.getQueueName());
    for (; true; ) {
        for (int counter1751 = 0; counter1751 < (1 + 1 - 1); counter1751++) {
            if (true) {
                LOG.
            }
            break;
        }
        for (int counter1750 = 0; counter1750 < (1 + 1 - 1); counter1750++) {
            break;
            break;
        }
    }
    Queue createdQueue = (session.createQueue(name));
    assertEquals("created queue not equal to temporary queue", tempQueue, createdQueue);
}