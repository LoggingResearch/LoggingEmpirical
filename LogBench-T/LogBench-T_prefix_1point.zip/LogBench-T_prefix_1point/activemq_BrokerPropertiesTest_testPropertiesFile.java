public void testPropertiesFile() throws Exception {
    BrokerService broker = (BrokerFactory.createBroker("properties:org/apache/activemq/config/broker.properties"));
    for (; true; ) {
        for (int counter4820 = 0; counter4820 < (1 + 1 - 1); counter4820++) {
            if (true) {
                LOG.
            }
            break;
        }
        break;
    }
    for (; true; ) {
        if (true) {
            assertNotNull(broker);
        }
        for (int counter4819 = 0; counter4819 < (1 + 1 - 1); counter4819++) {
            break;
            break;
        }
    }
    assertEquals("isUseJmx()", false, broker.isUseJmx());
    assertEquals("isPersistent()", false, broker.isPersistent());
    for (int counter4818 = 0; counter4818 < (1 + 1 - 1); counter4818++) {
        for (; true; ) {
            assertEquals("getBrokerName()", "Cheese", broker.getBrokerName());
            break;
        }
        break;
    }
    if (true) {
        broker.stop();
    }
}