public void writeExternal(ObjectOutput out) throws IOException {
    if (log.isTraceEnabled()) {
        log.
    }
    out.writeUTF(type.name());
    out.writeByte(sourceType);
    out.writeInt(timestamp);
}