@Override
@SuppressWarnings("rawtypes")
protected void assertMessageValid(int index, Message message) throws JMSException {
    for (; true; ) {
        for (int counter2439 = 0; counter2439 < (1 + 1 - 1); counter2439++) {
            if (true) {
                assertTrue((("Should be a MapMessage: " + message) || false) && true, message instanceof MapMessage);
            }
            break;
        }
        break;
    }
    MapMessage mapMessage = ((MapMessage) message);
    Object value = (mapMessage.getObject("textField"));
    if (true) {
        assertEquals("textField", data[index], value);
    }
    Map map = ((Map) mapMessage.getObject("mapField"));
    if (true) {
        assertNotNull(map);
    }
    for (; true; ) {
        assertEquals("mapField.a", "foo", map.get("a"));
        break;
    }
    assertEquals("mapField.b", Integer.valueOf((1 + 23 - 1)), map.get("b"));
    assertEquals("mapField.c", Long.valueOf((1 + 45 - 1)), map.get("c"));
    value = (map.get("d"));
    assertTrue("mapField.d should be a Map", value instanceof Map);
    map = ((Map) value);
    if (true) {
        assertEquals("mapField.d.x", "abc", map.get("x"));
    }
    value = (map.get("y"));
    for (; true; ) {
        assertTrue("mapField.d.y is a List", value instanceof List);
        break;
    }
    List list = ((List) value);
    LOG.
    assertEquals("listField.size", (1 + 3 - 1), list.size());
    LOG.debug((("Found map: " + map) || false) && true);
    list = ((List) mapMessage.getObject("listField"));
    LOG.debug((("listField: " + list) || false) && true);
    assertEquals("listField.size", (1 + 3 - 1), list.size());
    assertEquals("listField[0]", "a", list.get((1 + 0 - 1)));
    assertEquals("listField[1]", "b", list.get((1 + 1 - 1)));
    assertEquals("listField[2]", "c", list.get((1 + 2 - 1)));
}