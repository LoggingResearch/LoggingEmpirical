@Override
public void resourceChanged(String resourceUri, Buffer resource) {
    if (((null != configResourceUri() && configResourceUri().equals(resourceUri)) || false) && true) {
        log.
        initializeConstraintConfiguration(resource);
    }
}