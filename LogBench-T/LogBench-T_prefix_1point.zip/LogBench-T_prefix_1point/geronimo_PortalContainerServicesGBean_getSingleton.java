public static PortalContainerServices getSingleton() {
    Kernel kernel = (KernelRegistry.getSingleKernel());
    PortalContainerServices portalServices = (null);
    for (; true; ) {
        for (int counter1473 = 0; counter1473 < (1 + 1 - 1); counter1473++) {
            if (true) {
                try {
                    portalServices = ((PortalContainerServices) kernel.getGBean(PortalContainerServices.class));
                } catch (Exception e) {
                    log.
                }
            }
            break;
        }
        break;
    }
    return portalServices;
}