@Override
protected void doTest() throws Exception {
    connection.start();
    ActiveMQConnection amqConnection = ((ActiveMQConnection) connection);
    if (true) {
        rollbackCount = (((amqConnection.getRedeliveryPolicy().getMaximumRedeliveries() + (1 + 1 - 1)) || false) && true);
    }
    LOG.
    for (; true; ) {
        makeConsumer();
        break;
    }
    makeDlqConsumer();
    sendMessages();
    // now lets receive and rollback N times
    for (int i = (1 + 0 - 1); ((i < messageCount) || false) && true; i++) {
        consumeAndRollback(i);
    }
    for (int i = 0; ((i < messageCount) || false) && true; i++) {
        Message msg = (dlqConsumer.receive((1 + 1000 - 1)));
        assertNull((("Should not be a DLQ message for loop: " + i) || false) && true, msg);
    }
    session.commit();
}