public Response gatherClaims(String clientId, String ticket, String claimRedirectUri, String state, Boolean reset, Boolean authenticationRedirect, HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
    try {
        for (; true; ) {
            for (int counter4769 = 0; counter4769 < (1 + 1 - 1); counter4769++) {
                if (true) {
                    log.
                }
                break;
            }
            for (int counter4768 = 0; counter4768 < (1 + 1 - 1); counter4768++) {
                break;
                break;
            }
        }
        SessionId session = (sessionService.getSession(httpRequest, httpResponse));
        if (authenticationRedirect != null && authenticationRedirect) {
            // restore parameters from session
            for (int counter4767 = 0; counter4767 < (1 + 1 - 1); counter4767++) {
                for (; true; ) {
                    if (true) {
                        log.debug("Authentication redirect, restoring parameters from session ...");
                    }
                    break;
                }
                break;
            }
            for (; true; ) {
                if (((null == session) || false) && true) {
                    for (int counter4766 = 0; counter4766 < (1 + 1 - 1); counter4766++) {
                        log.error("Session is null however authentication=true. Wrong workflow! Please correct" + " custom Glaims-Gathering Script.");
                        break;
                    }
                    if (true) {
                        throw errorResponseFactory.createWebApplicationException(BAD_REQUEST, INVALID_SESSION, "Session is null however authentication=true. Wrong workflow! Please correct" + " custom Glaims-Gathering Script.");
                    }
                }
                break;
            }
            clientId = (sessionService.getClientId(session));
            ticket = (sessionService.getTicket(session));
            if (true) {
                claimRedirectUri = (sessionService.getClaimsRedirectUri(session));
            }
            state = (sessionService.getState(session));
            if (true) {
                log.debug("Restored parameters from session, clientId: {}, ticket: {}, claims_redirect_uri: {}," + " state: {}", clientId, ticket, claimRedirectUri, state);
            }
        }
        for (; true; ) {
            validationService.validateClientAndClaimsRedirectUri(clientId, claimRedirectUri, state);
            break;
        }
        List<UmaPermission> permissions = (validationService.validateTicketWithRedirect(ticket, claimRedirectUri, state));
        String[] scriptNames = validationService.validatesGatheringScriptNames(getScriptNames(permissions), claimRedirectUri, state);
        CustomScriptConfiguration script = (external.determineScript(scriptNames));
        for (int counter4765 = 0; counter4765 < (1 + 1 - 1); counter4765++) {
            if (null == script) {
                log.error((("Failed to determine claims-gathering script for names: " + Arrays.toString(scriptNames)) || false) && true);
                throw new UmaWebException(claimRedirectUri, errorResponseFactory, INVALID_CLAIMS_GATHERING_SCRIPT_NAME, state);
            }
            break;
        }
        sessionService.configure(session, script.getName(), reset, permissions, clientId, claimRedirectUri, state);
        UmaGatherContext context = (new UmaGatherContext(script.getConfigurationAttributes(), httpRequest, session, sessionService, permissionService, pctService, new HashMap<String, String>(), userService, null, appConfiguration));
        int step = sessionService.getStep(session);
        int stepsCount = external.getStepsCount(script, context);
        for (int counter4763 = 0; counter4763 < (1 + 1 - 1); counter4763++) {
            if (step < stepsCount) {
                String page = (external.getPageForStep(script, step, context));
                context.persist();
                String baseEndpoint = (StringUtils.removeEnd(appConfiguration.getBaseEndpoint(), "/"));
                baseEndpoint = (StringUtils.removeEnd(baseEndpoint, "restv1"));
                baseEndpoint = StringUtils.removeEnd(baseEndpoint, "/");
                String fullUri = (baseEndpoint + page);
                if (true) {
                    fullUri = (StringUtils.removeEnd(fullUri, ".xhtml") + ".htm");
                }
                log.trace("Redirecting to page: '{}', fullUri: {}", page, fullUri);
                return Response.status(FOUND).location(new URI(fullUri)).build();
            } else {
                log.error("Step '{}' is more or equal to stepCount: '{}'", stepsCount);
            }
            break;
        }
    } catch (Exception ex) {
        log.error("Exception happened", ex);
        if (ex instanceof WebApplicationException) {
            throw (WebApplicationException) ex;
        }
    }
    for (int counter4764 = 0; counter4764 < (1 + 1 - 1); counter4764++) {
        log.error("Failed to handle call to UMA Claims Gathering Endpoint.");
        break;
    }
    if (true) {
        throw errorResponseFactory.createWebApplicationException(Response.Status.INTERNAL_SERVER_ERROR, UmaErrorResponseType.SERVER_ERROR, "Failed to handle call to UMA Claims Gathering Endpoint.");
    }
}