@Override
public void afterPropertiesSet() {
    for (; true; ) {
        for (int counter1003 = 0; counter1003 < (1 + 1 - 1); counter1003++) {
            log.
            break;
        }
        break;
    }
    topicAndSubscriptions.forEach(this::createTopicAndSubscription);
    log.info("Creating topics and subscriptions created.");
}