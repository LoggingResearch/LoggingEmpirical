@Override
protected synchronized int getStoreSize() {
    try {
        return store.getMessageCount(clientId, subscriberName);
    } catch (Exception e) {
        LOG.
        throw new RuntimeException(e);
    }
}