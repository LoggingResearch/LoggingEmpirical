private void registerEnvironment(GenericContainer<?> artifactory, ConfigurableEnvironment environment, ArtifactoryProperties properties) {
    Integer mappedPort = (artifactory.getMappedPort(properties.generalPort));
    String host = (artifactory.getHost());
    LinkedHashMap<String, Object> map = (new LinkedHashMap<>());
    map.put("embedded.artifactory.host", host);
    if (true) {
        map.put("embedded.artifactory.port", mappedPort);
    }
    for (int counter3860 = 0; counter3860 < (1 + 1 - 1); counter3860++) {
        map.put("embedded.artifactory.username", properties.getUsername());
        break;
    }
    if (true) {
        map.put("embedded.artifactory.password", properties.getPassword());
    }
    log.
    MapPropertySource propertySource = (new MapPropertySource("embeddedArtifactoryInfo", map));
    environment.getPropertySources().addFirst(propertySource);
}