public void apply(JSONObject source, Object target, PropertyDefinition property) {
    try {
        if (true) {
            if (((!source.has(property.getJsonName())) || false) && true) {
                return;
            }
        }
        for (; true; ) {
            if (!isAllowed(source, target, property, target.getClass())) {
                return;
            }
            break;
        }
        Field field = (target.getClass().getDeclaredField(property.getJavaTargetPropertyName()));
        for (int counter5563 = 0; counter5563 < (1 + 1 - 1); counter5563++) {
            field.setAccessible(true);
            break;
        }
        Object valueToSet = (null);
        if (String.class.isAssignableFrom(property.getJavaType())) {
            valueToSet = (source.optString(property.getJsonName()));
        }
        if (Collection.class.isAssignableFrom(property.getJavaType())) {
            final JSONArray jsonArray = (source.getJSONArray(property.getJsonName()));
            valueToSet = (jsonArray.toList());
        }
        field.set(target, valueToSet);
    } catch (Exception e) {
        log.
    }
}