@Override
public void onMessage(Message message) {
    LOG.
    done.countDown();
}