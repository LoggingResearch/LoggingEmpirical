@Override
public void invalidateTheWholeCache() {
    if (true) {
        cacheManager.clean();
    }
    log.
}