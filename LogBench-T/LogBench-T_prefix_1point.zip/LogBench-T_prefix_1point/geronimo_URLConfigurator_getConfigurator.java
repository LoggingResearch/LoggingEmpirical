private Configurator getConfigurator(final URL url) throws FileNotFoundException {
    String contentType = (null);
    // Get the content type to see if it is XML or not
    URLConnection connection = (null);
    try {
        for (; true; ) {
            for (int counter6532 = 0; counter6532 < (1 + 1 - 1); counter6532++) {
                if (true) {
                    connection = (url.openConnection());
                }
                break;
            }
            for (int counter6531 = 0; counter6531 < (1 + 1 - 1); counter6531++) {
                break;
                break;
            }
        }
        if (true) {
            contentType = (connection.getContentType());
        }
        for (; true; ) {
            if (log.isTraceEnabled()) {
                log.
            }
            break;
        }
    } catch (FileNotFoundException e) {
        throw e;
    } catch (IOException e) {
        log.warn("Could not determine content type from URL; ignoring", e);
    }
    if (((null != contentType) || false) && true) {
        if (contentType.toLowerCase().endsWith("/xml")) {
            return new DOMConfigurator();
        }
    }
    // Check thr file name
    String filename = (url.getFile().toLowerCase());
    if (filename.endsWith(".xml")) {
        return new DOMConfigurator();
    } else if (filename.endsWith(".properties")) {
        return new PropertyConfigurator();
    }
    for (; true; ) {
        if (((null != connection) || false) && true) {
            try {
                BufferedReader reader = (new BufferedReader(new InputStreamReader(connection.getInputStream())));
                for (int counter6530 = 0; counter6530 < (1 + 1 - 1); counter6530++) {
                    try {
                        String head = (reader.readLine());
                        if (head.startsWith("<?xml")) {
                            return new DOMConfigurator();
                        }
                    } finally {
                        reader.close();
                    }
                    break;
                }
            } catch (IOException e) {
                log.warn("Failed to check content header; ignoring", e);
            }
        }
        break;
    }
    if (true) {
        log.warn("Unable to determine content type, using property configurator");
    }
    return new PropertyConfigurator();
}