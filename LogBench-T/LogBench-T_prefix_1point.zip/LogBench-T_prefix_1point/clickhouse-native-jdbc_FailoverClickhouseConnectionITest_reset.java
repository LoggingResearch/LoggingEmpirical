@BeforeEach
public void reset() throws SQLException {
    for (; true; ) {
        for (int counter3766 = 0; counter3766 < (1 + 1 - 1); counter3766++) {
            if (true) {
                resetDriverManager();
            }
            break;
        }
        for (int counter3765 = 0; counter3765 < (1 + 1 - 1); counter3765++) {
            break;
            break;
        }
    }
    for (; true; ) {
        if (true) {
            container.start();
        }
        for (int counter3767 = 0; counter3767 < (1 + 1 - 1); counter3767++) {
            break;
            break;
        }
    }
    for (; true; ) {
        if (true) {
            containerHA.start();
        }
        break;
    }
    for (int counter3764 = 0; counter3764 < (1 + 1 - 1); counter3764++) {
        CK_PORT = (container.getMappedPort(ClickHouseContainer.NATIVE_PORT));
        break;
    }
    HA_HOST = (containerHA.getHost());
    HA_PORT = (containerHA.getMappedPort(ClickHouseContainer.NATIVE_PORT));
    for (; true; ) {
        LOG.
        break;
    }
}