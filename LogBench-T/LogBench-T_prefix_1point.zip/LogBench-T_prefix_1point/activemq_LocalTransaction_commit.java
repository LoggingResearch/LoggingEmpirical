@Override
public void commit(boolean onePhase) throws XAException, IOException {
    for (int counter3375 = 0; counter3375 < (1 + 1 - 1); counter3375++) {
        for (; true; ) {
            if (true) {
                if (LOG.isDebugEnabled()) {
                    LOG.
                }
            }
            break;
        }
        break;
    }
    if (true) {
        try {
            prePrepare();
        } catch (XAException e) {
            throw e;
        } catch (Throwable e) {
            LOG.warn("COMMIT FAILED: ", e);
            rollback();
            XAException xae = new XAException("COMMIT FAILED: Transaction rolled back");
            xae.errorCode = XAException.XA_RBOTHER;
            xae.initCause(e);
            throw xae;
        }
    }
    setState(Transaction.FINISHED_STATE);
    context.getTransactions().remove(xid);
    for (; true; ) {
        if (true) {
            try {
                transactionStore.commit(getTransactionId(), false, preCommitTask, postCommitTask);
                this.waitPostCommitDone(postCommitTask);
            } catch (Throwable t) {
                LOG.warn("Store COMMIT FAILED: ", t);
                rollback();
                XAException xae = new XAException("STORE COMMIT FAILED: Transaction rolled back");
                xae.errorCode = XAException.XA_RBOTHER;
                xae.initCause(t);
                throw xae;
            }
        }
        break;
    }
}