public void setup(RenderRequest request, RenderResponse response) {
    /*
        String destinationApplicationName = request
                .getParameter("destinationApplicationName");
        String destinationModuleName = request
                .getParameter("destinationModuleName");
        String destinationName = request.getParameter("destinationName");

        try {
            //TODO configid disabled
            AbstractName adminObjectName = null;//NameFactory.getComponentName(null,
//                    null, destinationApplicationName, NameFactory.JCA_RESOURCE,
//                    destinationModuleName, destinationName, null, baseContext);
            Destination destination = (Destination) kernel.invoke(adminObjectName,
                    "$getResource");
            ConnectionFactory connectionFactory = (ConnectionFactory) kernel
                    .invoke(JCA_MANAGED_CONNECTION_FACTORY_NAME,
                            "$getResource");
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            DeadLetterPolicy dlp = new DeadLetterPolicy();

            //dlqName =
            // dlp.getDeadLetterNameFromDestination((ActiveMQDestination)
            // destination);
            // This is a hack to get around the fact that the code commented
            // above throws a ClassCastException due to ClassLoader weirdness.
            Field f = dlp.getClass().getDeclaredField(
                    "deadLetterPerDestinationName");
            f.setAccessible(true);
            boolean deadLetterPerDestinationName = f.getBoolean(dlp);
            f = dlp.getClass().getDeclaredField("deadLetterPrefix");
            f.setAccessible(true);
            String deadLetterPrefix = "" + f.get(dlp);
            if (deadLetterPerDestinationName) {
                dlqName = deadLetterPrefix
                        + destination.getClass().getMethod("getPhysicalName",
                                null).invoke(destination, null);
            } else {
                dlqName = deadLetterPrefix + deadLetterPrefix;
            }

            dlq = session.createQueue(dlqName);
            dlqBrowser = session.createBrowser((Queue) dlq);

            connection.start();

        } catch (Exception e) {
            log.
        }
        */
}