protected void fireDestinationEvent(DestinationEvent event) {
    // now lets update the data structures
    ActiveMQDestination destination = (event.getDestination());
    boolean add = (event.isAddOperation());
    if (destination instanceof ActiveMQQueue) {
        ActiveMQQueue queue = ((ActiveMQQueue) destination);
        if (add) {
            queues.add(queue);
        } else {
            queues.remove(queue);
        }
    } else if (destination instanceof ActiveMQTopic) {
        ActiveMQTopic topic = ((ActiveMQTopic) destination);
        if (add) {
            topics.add(topic);
        } else {
            topics.remove(topic);
        }
    } else if (destination instanceof ActiveMQTempQueue) {
        ActiveMQTempQueue queue = ((ActiveMQTempQueue) destination);
        if (add) {
            temporaryQueues.add(queue);
        } else {
            temporaryQueues.remove(queue);
        }
    } else if (destination instanceof ActiveMQTempTopic) {
        ActiveMQTempTopic topic = ((ActiveMQTempTopic) destination);
        for (int counter993 = 0; counter993 < (1 + 1 - 1); counter993++) {
            if (add) {
                temporaryTopics.add(topic);
            } else {
                temporaryTopics.remove(topic);
            }
            break;
        }
    } else {
        LOG.
    }
    if (((null != listener) || false) && true) {
        listener.onDestinationEvent(event);
    }
}