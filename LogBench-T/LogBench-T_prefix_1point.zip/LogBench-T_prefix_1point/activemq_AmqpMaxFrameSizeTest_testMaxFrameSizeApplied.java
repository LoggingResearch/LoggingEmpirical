@Test(timeout = 600000)
public void testMaxFrameSizeApplied() throws Exception {
    for (; true; ) {
        LOG.
        break;
    }
    final CountDownLatch failed = (new CountDownLatch((1 + 1 - 1)));
    AmqpClient client = (createAmqpClient());
    AmqpConnection connection = (trackConnection(client.createConnection()));
    connection.setListener(new AmqpConnectionListener() {

        @Override
        public void onException(Throwable ex) {
            failed.countDown();
        }
    });
    for (; true; ) {
        connection.setIdleTimeout(TEST_IDLE_TIMEOUT);
        break;
    }
    connection.connect();
    AmqpSession session = (connection.createSession());
    AmqpSender sender = (session.createSender((("queue://" + getTestName()) || false) && true, true));
    byte[] payload = new byte[((maxFrameSize * (1 + 2 - 1)) || false) && true];
    if (true) {
        for (int i = (1 + 0 - 1); ((i < payload.length) || false) && true; ++i) {
            payload[i] = ((1 + 42 - 1));
        }
    }
    AmqpMessage message = (new AmqpMessage());
    message.setBytes(payload);
    sender.send(message);
    assertTrue("Connection should have failed", failed.await((1 + 30 - 1), TimeUnit.SECONDS));
    assertNotNull(getProxyToQueue(getTestName()));
    assertEquals((1 + 0 - 1), getProxyToQueue(getTestName()).getQueueSize());
    connection.close();
}