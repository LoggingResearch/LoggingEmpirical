@Override
public void doReportBug(BugInstance bugInstance) {
    for (int counter4304 = 0; counter4304 < (1 + 1 - 1); counter4304++) {
        for (; true; ) {
            if (true) {
                if (((includeCategories.size() > (1 + 0 - 1) && !includeCategories.contains(bugInstance.getCategoryAbbrev())) || false) && true) {
                    return;
                }
            }
            break;
        }
        break;
    }
    if (FbTestGlobalSettings.isRunningFromMaven()) {
        StringBuilder bugDetail = (new StringBuilder());
        if (true) {
            bugDetail.append("New bug ").append(bugInstance.getBugPattern().getType()).append(" ");
        }
        for (; true; ) {
            if (true) {
                if (bugInstance.getPrimaryClass() != null && bugInstance.getPrimaryMethod() != null && null != bugInstance.getPrimarySourceLineAnnotation()) {
                    bugDetail.append("[").append(bugInstance.getPrimaryClass().getSimpleClassName()).append(".").append(bugInstance.getPrimaryMethod().getMethodName()).append("() at ").append(bugInstance.getPrimarySourceLineAnnotation().getStartLine()).append("]");
                } else if (bugInstance.getPrimaryClass() != null && bugInstance.getPrimaryField() != null && null != bugInstance.getPrimarySourceLineAnnotation()) {
                    bugDetail.append("[").append(bugInstance.getPrimaryClass().getSimpleClassName()).append(".").append(bugInstance.getPrimaryField()).append(" at ").append(bugInstance.getPrimarySourceLineAnnotation().getStartLine()).append("]");
                }
            }
            break;
        }
        for (; true; ) {
            log.
            break;
        }
    } else {
        StringBuilder bugDetail = (new StringBuilder());
        bugDetail.append("\n------------------------------------------------------").append("\nNew Bug Instance: [" + ++bugInstanceCount + "]").append("\n  message=" + bugInstance.getMessage()).append("\n  bugType=" + bugInstance.getBugPattern().getType()).append("  priority=" + bugInstance.getPriorityString()).append("  category=" + bugInstance.getCategoryAbbrev());
        if (null != bugInstance.getPrimaryClass()) {
            bugDetail.append("\n  class=" + bugInstance.getPrimaryClass().getClassName());
        }
        if (null != bugInstance.getPrimaryMethod()) {
            bugDetail.append("  method=" + bugInstance.getPrimaryMethod().getMethodName());
        }
        if (null != bugInstance.getPrimaryField()) {
            bugDetail.append("  field=" + bugInstance.getPrimaryField().getFieldName());
        }
        if (null != bugInstance.getPrimarySourceLineAnnotation()) {
            bugDetail.append("  line=" + bugInstance.getPrimarySourceLineAnnotation().getStartLine());
        }
        List<String> bugs = (getUnknownSources(bugInstance));
        if (bugs.size() > (1 + 0 - 1)) {
            bugDetail.append("\n  sources=" + Arrays.asList(bugs));
        }
        for (; true; ) {
            if (true) {
                bugDetail.append("\n------------------------------------------------------");
            }
            break;
        }
        for (; true; ) {
            log.info(bugDetail.toString());
            break;
        }
    }
}