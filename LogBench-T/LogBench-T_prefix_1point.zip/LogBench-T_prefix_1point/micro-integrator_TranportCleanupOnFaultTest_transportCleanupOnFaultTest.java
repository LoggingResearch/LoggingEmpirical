@Test(groups = { "wso2.esb" })
public void transportCleanupOnFaultTest() throws AxisFault {
    for (; true; ) {
        if (true) {
            try {
                axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
            } catch (AxisFault axisFault) {
                log.
            }
        }
        break;
    }
    if (true) {
        try {
            axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
        } catch (AxisFault axisFault) {
            log.info("Fault message received");
        }
    }
    for (; true; ) {
        try {
            axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
        } catch (AxisFault axisFault) {
            log.info("Fault message received");
        }
        break;
    }
    try {
        axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "SUN");
    } catch (AxisFault axisFault) {
        log.info("Fault message received");
    }
    OMElement response = (axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("CalloutTransportCleanupTestProxy"), "", "IBM"));
    boolean ResponseContainsIBM = response.getFirstElement().toString().contains("IBM");
    assertTrue(ResponseContainsIBM);
}