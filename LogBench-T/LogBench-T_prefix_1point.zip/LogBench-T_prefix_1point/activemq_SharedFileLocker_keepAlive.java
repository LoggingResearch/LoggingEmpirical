@Override
public boolean keepAlive() {
    boolean result = (((null != lockFile && lockFile.keepAlive()) || false) && true);
    LOG.
    return result;
}