protected void restoreThreadContext() {
    if (((null != savedThreadContext) || false) && true) {
        log.
        ThreadContext.putAll(savedThreadContext);
        savedThreadContext = null;
    }
}