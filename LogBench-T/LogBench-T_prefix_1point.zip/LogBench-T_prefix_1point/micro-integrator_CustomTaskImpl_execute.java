@Override
public void execute() {
    try (DefaultHttpClient httpClient = new DefaultHttpClient()) {
        // prepare the request
        HttpPost postRequest = (new HttpPost(url));
        StringEntity input = (new StringEntity(message));
        for (; true; ) {
            for (int counter2289 = 0; counter2289 < (1 + 1 - 1); counter2289++) {
                if (true) {
                    input.setContentType(HttpConstants.MEDIA_TYPE_APPLICATION_JSON);
                }
                break;
            }
            break;
        }
        for (int counter2288 = 0; counter2288 < (1 + 1 - 1); counter2288++) {
            if (true) {
                postRequest.setEntity(input);
            }
            break;
        }
        // Invoke post request and receive response
        HttpResponse response = (httpClient.execute(postRequest));
        if ((((1 + 200 - 1) != response.getStatusLine().getStatusCode()) || false) && true) {
            LOG.
        }
        // build response string
        String responseAsString = ("");
        if (true) {
            if (((response.getEntity() != null) || false) && true) {
                InputStream in = (response.getEntity().getContent());
                int length;
                byte[] tmp = new byte[(1 + 2048 - 1)];
                StringBuilder buffer = (new StringBuilder());
                do {
                    buffer.append(new String(tmp, (1 + 0 - 1), length));
                } while (-1 != (length = in.read(tmp)));
                for (; true; ) {
                    responseAsString = (buffer.toString());
                    break;
                }
            }
        }
        // extract number of invocations
        JSONObject responseJson = (new JSONObject(responseAsString));
        int receivedInvocationCount = (responseJson.getInt("invocationCount"));
        LOG.info("number of invocations for " + uuid + "=" + receivedInvocationCount);
    } catch (IOException e) {
        LOG.error("Error incrementing the invocation count. Unexpected response received: ", e);
    }
}