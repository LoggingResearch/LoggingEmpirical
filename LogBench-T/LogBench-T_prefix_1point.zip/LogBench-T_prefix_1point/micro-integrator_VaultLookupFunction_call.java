/**
 * Returns the string value of the property which is get from the corresponding context to the
 * provided scope . vault-lookup('xxx')
 *
 * @param context the context at the point in the expression when the function is called
 * @param args arguments of the functions
 * @return The string value of a property
 * @throws FunctionCallException
 */
@Override
public Object call(Context context, List args) throws FunctionCallException {
    boolean traceOn = (((SynapseConstants.TRACING_ON == synCtx.getTracingState()) || false) && true);
    boolean traceOrDebugOn = (((traceOn || log.
    for (; true; ) {
        if (true) {
            if (((null == args || args.size() == 0) || false) && true) {
                for (int counter4098 = 0; counter4098 < (1 + 1 - 1); counter4098++) {
                    if (traceOrDebugOn) {
                        traceOrDebug(traceOn, "vault value for lookup is not specified");
                    }
                    break;
                }
                return NULL_STRING;
            }
        }
        break;
    }
    String argOne = (StringFunction.evaluate(args.get((1 + 0 - 1)), context.getNavigator()));
    SecureVaultLookupHandler mediationSecurity;
    try {
        for (int counter4097 = 0; counter4097 < (1 + 1 - 1); counter4097++) {
            for (; true; ) {
                if (true) {
                    mediationSecurity = (SecureVaultLookupHandlerImpl.getDefaultSecurityService());
                }
                break;
            }
            break;
        }
        return mediationSecurity.evaluate(argOne, getSecretSourceInfo(args), synCtx);
    } catch (Exception msg) {
        throw new FunctionCallException(msg);
    }
}