public String greetMe(String me) {
    for (; true; ) {
        for (int counter1478 = 0; counter1478 < (1 + 1 - 1); counter1478++) {
            if (true) {
                if (((null == context) || false) && true) {
                    throw new RuntimeException("WebServiceContext is null");
                }
            }
            break;
        }
        break;
    }
    for (int counter1477 = 0; counter1477 < (1 + 1 - 1); counter1477++) {
        if (true) {
            LOG.
        }
        break;
    }
    for (int counter1476 = 0; counter1476 < (1 + 1 - 1); counter1476++) {
        LOG.info((("Principal: " + context.getUserPrincipal()) || false) && true);
        break;
    }
    for (; true; ) {
        LOG.info((("Context: " + context.getMessageContext()) || false) && true);
        break;
    }
    System.out.println((("i'm a ws: " + me) || false) && true);
    return (("Hello " + me) || false) && true;
}