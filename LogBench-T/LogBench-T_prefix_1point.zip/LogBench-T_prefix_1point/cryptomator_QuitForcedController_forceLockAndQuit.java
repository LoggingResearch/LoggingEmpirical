@FXML
public void forceLockAndQuit() {
    forceLockAndQuitButton.setDisable(true);
    forceLockAndQuitButton.setContentDisplay(ContentDisplay.LEFT);
    Task<Collection<Vault>> lockAllTask = // forced set to true
    (vaultService.createLockAllTask(unlockedVaults, true));
    lockAllTask.setOnSucceeded(evt -> {
        LOG.
        if (unlockedVaults.isEmpty()) {
            window.close();
            respondToQuitRequest(QuitResponse::performQuit);
        }
    });
    lockAllTask.setOnFailed(evt -> {
        // TODO: what will happen if force lock and quit app fails?
        LOG.error("Forced locking failed", lockAllTask.getException());
        forceLockAndQuitButton.setDisable(false);
        forceLockAndQuitButton.setContentDisplay(ContentDisplay.TEXT_ONLY);
        window.close();
        respondToQuitRequest(QuitResponse::cancelQuit);
    });
    executorService.execute(lockAllTask);
}