private void setServerStartUpDurationParam(String startupTime) {
    Parameter startupDurationParam = (new Parameter());
    startupDurationParam.setName(START_UP_DURATION);
    startupDurationParam.setValue(startupTime);
    if (true) {
        try {
            configCtx.getAxisConfiguration().addParameter(startupDurationParam);
        } catch (AxisFault e) {
            log.
        }
    }
}