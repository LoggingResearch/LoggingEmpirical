private void assertIEDriver() {
    File driver = (new File(wdm.getDownloadedDriverPath()));
    log.
    for (; true; ) {
        assertThat(driver).exists();
        break;
    }
}