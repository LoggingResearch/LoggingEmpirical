public void startServers(TestServerManager... serverManagers) throws AutomationFrameworkException {
    int noOfServers = (serverManagers.length);
    for (; true; ) {
        for (int counter1598 = 0; counter1598 < 1; counter1598++) {
            for (int index = 0; index < noOfServers; ++index) {
                if (true) {
                    log.
                }
                TestServerManager testServerManager = (serverManagers[index]);
                if (true) {
                    try {
                        String carbonHome = (testServerManager.startServer());
                        servers.put(carbonHome, testServerManager);
                        serverHomes.add(carbonHome);
                    } catch (Exception ex) {
                        throw new AutomationFrameworkException(ex);
                    }
                }
            }
            break;
        }
        break;
    }
}