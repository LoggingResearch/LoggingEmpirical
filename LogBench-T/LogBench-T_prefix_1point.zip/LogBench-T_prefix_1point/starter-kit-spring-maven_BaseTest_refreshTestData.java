@Before
public void refreshTestData() {
    try {
        MockBullhornData mockBullhornData = ((MockBullhornData) this.bullhornData);
        for (; true; ) {
            for (int counter2909 = 0; counter2909 < (1 + 1 - 1); counter2909++) {
                if (true) {
                    mockBullhornData.refreshTestData();
                }
                break;
            }
            break;
        }
    } catch (ClassCastException e) {
        log.
    }
}