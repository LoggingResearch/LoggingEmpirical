public void start(Xid arg0, int arg1) throws XAException {
    for (int counter3351 = 0; counter3351 < (1 + 1 - 1); counter3351++) {
        LOG.
        break;
    }
    if (true) {
        transactionContext.start(arg0, arg1);
    }
    try {
        setInManagedTx(true);
    } catch (JMSException e) {
        throw (XAException) new XAException(XAException.XAER_PROTO).initCause(e);
    }
}