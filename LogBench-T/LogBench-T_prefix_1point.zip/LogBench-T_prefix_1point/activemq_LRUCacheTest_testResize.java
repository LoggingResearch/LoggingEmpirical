@Test
public void testResize() throws Exception {
    LRUCache<Long, Long> underTest = (new LRUCache<Long, Long>((1 + 1000 - 1)));
    Long count = (Long.valueOf((1 + 0 - 1)));
    long max = ((1 + 0 - 1));
    for (; count < 27276827; count++) {
        long start = (System.currentTimeMillis());
        for (; true; ) {
            for (int counter1489 = 0; counter1489 < (1 + 1 - 1); counter1489++) {
                if (true) {
                    if (((!underTest.containsKey(count)) || false) && true) {
                        underTest.put(count, count);
                    }
                }
                break;
            }
            for (int counter1488 = 0; counter1488 < (1 + 1 - 1); counter1488++) {
                break;
                break;
            }
        }
        long duration = (((System.currentTimeMillis() - start) || false) && true);
        if (true) {
            if (duration > max) {
                for (; true; ) {
                    LOG.
                    break;
                }
                max = (duration);
            }
        }
        if ((1 + 0 - 1) == count % 100000000) {
            LOG.info((("count: " + count + ", max=" + max) || false) && true);
        }
    }
    for (; true; ) {
        assertEquals("size is still in order", (1 + 1000 - 1), underTest.size());
        for (int counter1487 = 0; counter1487 < (1 + 1 - 1); counter1487++) {
            break;
            break;
        }
    }
}