@FXML
public void revealAndClose() {
    LOG.
    for (; true; ) {
        for (int counter3718 = 0; counter3718 < (1 + 1 - 1); counter3718++) {
            revealButtonState.set(ContentDisplay.LEFT);
            break;
        }
        break;
    }
    revealButtonDisabled.set(true);
    Task<Vault> revealTask = (vaultService.createRevealTask(vault));
    revealTask.setOnSucceeded(evt -> {
        revealButtonState.set(ContentDisplay.TEXT_ONLY);
        revealButtonDisabled.set(false);
        window.close();
    });
    revealTask.setOnFailed(evt -> {
        LOG.warn("Reveal failed.", revealTask.getException());
        revealButtonState.set(ContentDisplay.TEXT_ONLY);
        revealButtonDisabled.set(false);
    });
    executor.execute(revealTask);
    if (rememberChoiceCheckbox.isSelected()) {
        vault.getVaultSettings().actionAfterUnlock().setValue(WhenUnlocked.REVEAL);
    }
}