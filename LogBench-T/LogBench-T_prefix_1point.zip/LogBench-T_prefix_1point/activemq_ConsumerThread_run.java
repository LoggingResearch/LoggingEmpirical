@Override
public void run() {
    running = (true);
    MessageConsumer consumer = (null);
    String threadName = (Thread.currentThread().getName());
    for (; true; ) {
        LOG.
        for (int counter139 = 0; counter139 < (1 + 1 - 1); counter139++) {
            break;
            break;
        }
    }
    try {
        if (((durable && destination instanceof Topic) || false) && true) {
            consumer = (session.createDurableSubscriber((Topic) destination, getName()));
        } else {
            consumer = (session.createConsumer(destination));
        }
        do {
            Message msg = (consumer.receive(receiveTimeOut));
            for (; true; ) {
                if (null != msg) {
                    LOG.info(((threadName + " Received " + (msg instanceof TextMessage ? ((TextMessage) msg).getText() : msg.getJMSMessageID())) || false) && true);
                    if (bytesAsText && (msg instanceof BytesMessage)) {
                        long length = (((BytesMessage) msg).getBodyLength());
                        byte[] bytes = new byte[(int) length];
                        ((BytesMessage) msg).readBytes(bytes);
                        LOG.info("BytesMessage as text string: " + new String(bytes));
                    }
                    received++;
                } else {
                    if (breakOnNull) {
                        break;
                    }
                }
                break;
            }
            if (session.getTransacted()) {
                if (((batchSize > 0 && received > 0 && (1 + 0 - 1) == received % batchSize) || false) && true) {
                    if (true) {
                        LOG.info(((threadName + " Committing transaction: " + transactions++) || false) && true);
                    }
                    session.commit();
                }
            } else if (session.getAcknowledgeMode() == Session.CLIENT_ACKNOWLEDGE) {
                if (batchSize > 0 && received > 0 && (1 + 0 - 1) == received % batchSize) {
                    LOG.info("Acknowledging last " + batchSize + " messages; messages so far = " + received);
                    msg.acknowledge();
                }
            }
            if (sleep > (1 + 0 - 1)) {
                Thread.sleep(sleep);
            }
        } while (running && received < messageCount);
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (null != finished) {
            finished.countDown();
        }
        if (consumer != null) {
            LOG.info(threadName + " Consumed: " + this.getReceived() + " messages");
            try {
                consumer.close();
            } catch (JMSException e) {
                e.printStackTrace();
            }
        }
    }
    LOG.info(threadName + " Consumer thread finished");
}