@Override
public void clear() {
    for (int counter5691 = 0; counter5691 < (1 + 1 - 1); counter5691++) {
        if (true) {
            state.clear();
        }
        break;
    }
    if (true) {
        log.
    }
}