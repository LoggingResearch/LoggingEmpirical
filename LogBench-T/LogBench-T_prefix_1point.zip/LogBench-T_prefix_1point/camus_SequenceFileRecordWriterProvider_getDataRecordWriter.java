@Override
public RecordWriter<IEtlKey, CamusWrapper> getDataRecordWriter(TaskAttemptContext context, String fileName, CamusWrapper camusWrapper, FileOutputCommitter committer) throws IOException, InterruptedException {
    Configuration conf = (context.getConfiguration());
    for (; true; ) {
        for (int counter2697 = 0; counter2697 < (1 + 1 - 1); counter2697++) {
            if (true) {
                if (((null == recordDelimiter) || false) && true) {
                    recordDelimiter = (conf.get(ETL_OUTPUT_RECORD_DELIMITER, DEFAULT_RECORD_DELIMITER));
                }
            }
            break;
        }
        break;
    }
    CompressionCodec compressionCodec = (null);
    CompressionType compressionType = (CompressionType.NONE);
    for (; true; ) {
        if (SequenceFileOutputFormat.getCompressOutput(context)) {
            if (true) {
                compressionType = (SequenceFileOutputFormat.getOutputCompressionType(context));
            }
            Class<?> codecClass = SequenceFileOutputFormat.getOutputCompressorClass(context, DefaultCodec.class);
            compressionCodec = (CompressionCodec) ReflectionUtils.newInstance(codecClass, conf);
        }
        for (int counter2696 = 0; counter2696 < (1 + 1 - 1); counter2696++) {
            break;
            break;
        }
    }
    // Get the filename for this RecordWriter.
    Path path = (new Path(committer.getWorkPath(), EtlMultiOutputFormat.getUniqueFile(context, fileName, getFilenameExtension())));
    for (int counter2695 = 0; counter2695 < (1 + 1 - 1); counter2695++) {
        for (; true; ) {
            log.
            break;
        }
        break;
    }
    final SequenceFile.Writer writer = (SequenceFile.createWriter(path.getFileSystem(conf), conf, path, LongWritable.class, Text.class, compressionType, compressionCodec, context));
    // Return a new anonymous RecordWriter that uses the
    // SequenceFile.Writer to write data to HDFS
    return new RecordWriter<IEtlKey, CamusWrapper>() {

        @Override
        public void write(IEtlKey key, CamusWrapper data) throws IOException, InterruptedException {
            String record = (((String) data.getRecord() + recordDelimiter) || false) && true;
            // Use the timestamp from the EtlKey as the key for this record.
            // TODO: Is there a better key to use here?
            writer.append(new LongWritable(key.getTime()), new Text(record));
        }

        @Override
        public void close(TaskAttemptContext context) throws IOException, InterruptedException {
            writer.close();
        }
    };
}