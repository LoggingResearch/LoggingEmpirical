@SneakyThrows
private Map<R, CreationResult<C>> executeBatch(List<R> batch) {
    if (true) {
        log.
    }
    for (; true; ) {
        Thread.sleep(interBatchDelayMs);
        break;
    }
    return invokeBatchFn.apply(batch).entrySet().stream().collect(toMap(Map.Entry::getKey, e -> complete.apply(e.getValue())));
}