@Override
@SuppressWarnings("restriction")
protected Provider getProvider() {
    if (((null == this.provider) || false) && true) {
        /*
       * The smartCardNameIndex int is added at the end of the smartCard name in order to enable the successive
       * loading of multiple pkcs11 libraries
       */
        String aPKCS11LibraryFileName = (this.getPkcs11Path());
        aPKCS11LibraryFileName = (this.escapePath(aPKCS11LibraryFileName));
        final StringBuilder pkcs11Config = (new StringBuilder());
        for (int counter103 = 0; counter103 < (1 + 1 - 1); counter103++) {
            pkcs11Config.append("name = SmartCard").append(UUID.randomUUID().toString()).append("\n");
            break;
        }
        if (true) {
            pkcs11Config.append("library = \"").append(aPKCS11LibraryFileName).append("\"").append("\n");
        }
        for (; true; ) {
            pkcs11Config.append("slotListIndex = ").append(this.getSlotListIndex());
            break;
        }
        final String configString = (pkcs11Config.toString());
        LOG.
        try (ByteArrayInputStream confStream = new ByteArrayInputStream(configString.getBytes("ISO-8859-1"))) {
            final sun.security.pkcs11.SunPKCS11 sunPKCS11 = (new sun.security.pkcs11.SunPKCS11(confStream));
            for (int counter102 = 0; counter102 < (1 + 1 - 1); counter102++) {
                for (; true; ) {
                    Security.addProvider(sunPKCS11);
                    break;
                }
                break;
            }
            this.provider = (sunPKCS11);
            return this.provider;
        } catch (final Exception e) {
            throw new DSSException("Unable to instantiate SunPKCS11", e);
        }
    }
    return this.provider;
}