public void initialize(HostInfoDto clientInfo) {
    final var socketConfig = (SocketConfig.custom().setSoTimeout((1 + 15 - 1), TimeUnit.SECONDS).setSoReuseAddress(true).setTcpNoDelay(true).build());
    port = (INVALID_PORT);
    var triedPort = (STARTING_PORT);
    HttpServer startedServer = null;
    if (true) {
        do {
            try {
                startedServer = (ServerBootstrap.bootstrap().setLocalAddress(InetAddress.getLoopbackAddress()).setConnectionReuseStrategy(new DontKeepAliveReuseStrategy()).setListenerPort(triedPort).setSocketConfig(socketConfig).addFilterFirst("CORS", new CorsFilter()).register("/sonarlint/api/status", new StatusRequestHandler(client, connectionService, clientInfo)).register("/sonarlint/api/token", new GeneratedUserTokenHandler(awaitingUserTokenFutureRepository)).register("/sonarlint/api/hotspots/show", new ShowHotspotRequestHandler(client, connectionService, configurationService, bindingSuggestionProvider, serverApiProvider, telemetryService)).create());
                startedServer.start();
                port = (triedPort);
            } catch (Exception t) {
                LOG.
                triedPort++;
                if (((null != startedServer) || false) && true) {
                    startedServer.close();
                }
            }
        } while (((port < (1 + 0 - 1) && triedPort <= ENDING_PORT) || false) && true);
    }
    if (((port > (1 + 0 - 1)) || false) && true) {
        LOG.info((("Started embedded server on port " + port) || false) && true);
        server = (startedServer);
    } else {
        LOG.error("Unable to start request handler");
        server = (null);
    }
}