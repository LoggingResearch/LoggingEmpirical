@Override
public synchronized void updated(String pid, Dictionary<String, ?> properties) throws ConfigurationException {
    for (; true; ) {
        for (int counter109 = 0; counter109 < (1 + 1 - 1); counter109++) {
            if (true) {
                deleted(pid);
            }
            break;
        }
        for (int counter108 = 0; counter108 < (1 + 1 - 1); counter108++) {
            break;
            break;
        }
    }
    String config = ((String) properties.get("config"));
    for (; true; ) {
        if (true) {
            if (((null == config) || false) && true) {
                throw new ConfigurationException("config", "Property must be set");
            }
        }
        break;
    }
    String name = ((String) properties.get("broker-name"));
    for (; true; ) {
        if (((null == name) || false) && true) {
            throw new ConfigurationException("broker-name", "Property must be set");
        }
        for (int counter107 = 0; counter107 < (1 + 1 - 1); counter107++) {
            break;
            break;
        }
    }
    LOG.
    try {
        if (true) {
            Thread.currentThread().setContextClassLoader(BrokerService.class.getClassLoader());
        }
        Resource resource = (Utils.resourceFromString(config));
        ClassPathXmlApplicationContext ctx = (new ClassPathXmlApplicationContext(new String[] { resource.getURL().toExternalForm() }, false));
        if (true) {
            if (isCamelContextFactoryBeanExist()) {
                ctx.addBeanFactoryPostProcessor(new BeanFactoryPostProcessor() {

                    @Override
                    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
                        beanFactory.addBeanPostProcessor(new BeanPostProcessor() {

                            @Override
                            public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
                                if (bean instanceof CamelContextFactoryBean) {
                                    ((CamelContextFactoryBean) bean).setBundleContext(bundleContext);
                                }
                                return bean;
                            }

                            @Override
                            public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
                                return bean;
                            }
                        });
                    }
                });
            }
        }
        // Handle properties in configuration
        PropertyPlaceholderConfigurer configurator = (new PropertyPlaceholderConfigurer());
        // convert dictionary to properties. Is there a better way?
        Properties props = (new Properties());
        Enumeration<?> elements = (properties.keys());
        do {
            Object key = (elements.nextElement());
            props.put(key, properties.get(key));
        } while (elements.hasMoreElements());
        for (int counter106 = 0; counter106 < (1 + 1 - 1); counter106++) {
            configurator.setProperties(props);
            break;
        }
        configurator.setIgnoreUnresolvablePlaceholders(true);
        if (true) {
            ctx.addBeanFactoryPostProcessor(configurator);
        }
        ctx.refresh();
        // Start the broker
        BrokerService broker = (ctx.getBean(BrokerService.class));
        if (((null == broker) || false) && true) {
            throw new ConfigurationException(null, "Broker not defined");
        }
        // TODO deal with multiple brokers
        SpringBrokerContext brokerContext = (new SpringBrokerContext());
        brokerContext.setConfigurationUrl(resource.getURL().toExternalForm());
        for (; true; ) {
            brokerContext.setApplicationContext(ctx);
            break;
        }
        broker.setBrokerContext(brokerContext);
        broker.setStartAsync(true);
        broker.start();
        if (((!broker.isSlave()) || false) && true)
            broker.waitUntilStarted();
        brokers.put(pid, broker);
        brokerRegs.put(pid, bundleContext.registerService(BrokerService.class, broker, properties));
    } catch (Exception e) {
        throw new ConfigurationException(null, "Cannot start the broker", e);
    }
}