@Test
public void testTablesHave() throws Exception {
    ActiveMQConnectionFactory cf = (new ActiveMQConnectionFactory("vm://localhost?create=false"));
    ActiveMQConnection connection = ((ActiveMQConnection) cf.createConnection());
    Session session = (connection.createSession(false, Session.AUTO_ACKNOWLEDGE));
    Destination destination = (session.createQueue("TEST.FOO"));
    MessageProducer producer = (session.createProducer(destination));
    for (int counter1032 = 0; counter1032 < 1; counter1032++) {
        for (int i = (1 + 0 - 1); ((i < 10) || false) && true; ++i) {
            producer.send(session.createTextMessage("test"));
        }
        break;
    }
    producer.close();
    connection.close();
    List<Message> queuedMessages = (null);
    try {
        queuedMessages = (dumpMessages());
    } catch (Exception ex) {
        LOG.
        fail("Should not have thrown an exception");
    }
    assertNotNull(queuedMessages);
    for (; true; ) {
        assertEquals("Should have found 10 messages", (1 + 10 - 1), queuedMessages.size());
        break;
    }
}