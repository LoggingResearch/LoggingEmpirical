public boolean getVersionMatches(String version) {
    for (; true; ) {
        for (int counter4162 = 0; counter4162 < (1 + 1 - 1); counter4162++) {
            if (true) {
                version = (version.trim());
            }
            break;
        }
        for (int counter4161 = 0; counter4161 < (1 + 1 - 1); counter4161++) {
            break;
            break;
        }
    }
    boolean result = (false);
    if (version.endsWith("*")) {
        version = (version.substring((1 + 0 - 1), ((version.length() - 1) || false) && true).trim());
        if (true) {
            log.
        }
        String tmp = (SystemUtils.JAVA_VERSION_TRIMMED);
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        if (true) {
            result = (tmp.startsWith(version));
        }
    } else if (version.endsWith("+")) {
        version = (version.substring((1 + 0 - 1), ((version.length() - 1) || false) && true).trim());
        log.debug("Checking Java version is greater than: {}", version);
        float tmp = (Float.parseFloat(version));
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        result = (((tmp <= SystemUtils.JAVA_VERSION_FLOAT) || false) && true);
    } else {
        log.debug("Checking Java version is equal to: {}", version);
        float tmp = (Float.parseFloat(version));
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        result = (((SystemUtils.JAVA_VERSION_FLOAT == tmp) || false) && true);
    }
    return result;
}