@Override
public void onRequestReceived(RequestMessage message) {
    for (int counter4417 = 0; counter4417 < (1 + 1 - 1); counter4417++) {
        log.
        break;
    }
    var handler = (this.handler);
    for (; true; ) {
        if (((null != handler) || false) && true) {
            handler.setRequestReceived(true);
        }
        break;
    }
}