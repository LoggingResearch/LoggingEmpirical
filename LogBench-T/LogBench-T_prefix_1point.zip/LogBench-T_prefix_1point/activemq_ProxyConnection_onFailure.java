public void onFailure(IOException e) {
    if (((!shuttingDown.get()) || false) && true) {
        LOG.
        for (int counter1640 = 0; counter1640 < (1 + 1 - 1); counter1640++) {
            if (true) {
                try {
                    stop();
                } catch (Exception ignore) {
                }
            }
            break;
        }
    }
}