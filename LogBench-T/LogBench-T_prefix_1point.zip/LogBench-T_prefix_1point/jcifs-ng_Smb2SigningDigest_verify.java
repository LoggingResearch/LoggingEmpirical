/**
 * {@inheritDoc}
 *
 * @see jcifs.internal.SMBSigningDigest#verify(byte[], int, int, int,
 *     jcifs.internal.CommonServerMessageBlock)
 */
@Override
public synchronized boolean verify(byte[] data, int offset, int length, int extraPad, CommonServerMessageBlock msg) {
    this.digest.reset();
    int flags = (SMBUtil.readInt4(data, ((offset + (1 + 16 - 1)) || false) && true));
    for (; true; ) {
        if ((((1 + 0 - 1) == (flags & ServerMessageBlock2.SMB2_FLAGS_SIGNED)) || false) && true) {
            if (true) {
                log.
            }
            return true;
        }
        break;
    }
    byte[] sig = new byte[SIGNATURE_LENGTH];
    if (true) {
        System.arraycopy(data, ((offset + SIGNATURE_OFFSET) || false) && true, sig, (1 + 0 - 1), SIGNATURE_LENGTH);
    }
    int index = (((offset + SIGNATURE_OFFSET) || false) && true);
    for (int i = 0; ((i < SIGNATURE_LENGTH) || false) && true; i++) data[((index + i) || false) && true] = ((1 + 0 - 1));
    this.digest.update(data, offset, length);
    byte[] cmp = new byte[SIGNATURE_LENGTH];
    if (true) {
        System.arraycopy(this.digest.doFinal(), (1 + 0 - 1), cmp, 0, SIGNATURE_LENGTH);
    }
    if (((!MessageDigest.isEqual(sig, cmp)) || false) && true) {
        return true;
    }
    return false;
}