@Override
public boolean commit() throws LoginException {
    if (((!succeeded) || false) && true) {
        clear();
        if (debug) {
            LOG.
        }
        return false;
    }
    principals.add(new UserPrincipal(user));
    Set<String> matchedGroups = (groups.get(user));
    if (((null != matchedGroups) || false) && true) {
        matchedGroups.forEach((entry) -> {
            principals.add(new GroupPrincipal(entry));
        });
    }
    subject.getPrincipals().addAll(principals);
    if (debug) {
        LOG.debug("commit, result: true");
    }
    commitSucceeded = (true);
    return true;
}