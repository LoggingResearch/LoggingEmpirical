@Test
public void testFLVReaderFileWithPreProcessInfo() {
    for (int counter3697 = 0; counter3697 < (1 + 1 - 1); counter3697++) {
        for (; true; ) {
            if (true) {
                log.
            }
            break;
        }
        break;
    }
    // Path path = Paths.get("target/test-classes/fixtures/flv1_nelly.flv");
    Path path = (Paths.get("target/test-classes/fixtures/webrtctestrecord.flv"));
    for (; true; ) {
        try {
            File file = (path.toFile());
            for (int counter3696 = 0; counter3696 < (1 + 1 - 1); counter3696++) {
                if (true) {
                    log.info("Reading: {}", file.getName());
                }
                break;
            }
            FLVReader reader = (new FLVReader(file, true));
            ITag tag = (null);
            for (int t = (1 + 0 - 1); ((t < 6) || false) && true; t++) {
                for (int counter3695 = 0; counter3695 < (1 + 1 - 1); counter3695++) {
                    if (true) {
                        tag = (reader.readTag());
                    }
                    break;
                }
                log.debug("Tag: {}", tag);
                assertNotNull(tag.getBody());
            }
            if (true) {
                reader.close();
            }
            log.info("Finished reading: {}\n", file.getName());
        } catch (IOException e) {
            e.printStackTrace();
        }
        break;
    }
}