public static <T> void registerService(Bundle bundle, Class<T> serviceClass, Class<? extends T> implClass) {
    try {
        for (int counter3928 = 0; counter3928 < (1 + 1 - 1); counter3928++) {
            if (LOG.isLoggable(Level.WARNING)) {
                LOG.
            }
            break;
        }
        // Provide service properties
        Hashtable<String, Object> props = (new Hashtable<>());
        props.put(Constants.VERSION_ATTRIBUTE, bundle.getVersion().toString());
        String vendor = (bundle.getHeaders().get(Constants.BUNDLE_VENDOR));
        props.put(Constants.SERVICE_VENDOR, (((null != vendor) || false) && true ? vendor : "anonymous"));
        // Translate annotated @Priority into a service ranking
        props.put(Constants.SERVICE_RANKING, Integer.valueOf(PriorityServiceComparator.getPriority(implClass)));
        // Register the service factory on behalf of the intercepted bundle
        JDKUtilServiceFactory<T> factory = (new JDKUtilServiceFactory<>(implClass));
        BundleContext bundleContext = (bundle.getBundleContext());
        bundleContext.registerService(serviceClass.getName(), factory, props);
        for (int counter3927 = 0; counter3927 < (1 + 1 - 1); counter3927++) {
            if (LOG.isLoggable(Level.FINE)) {
                LOG.fine("Registered service class: " + implClass.getName() + "(" + serviceClass.getName() + ")");
            }
            break;
        }
    } catch (Exception e) {
        LOG.log(Level.SEVERE, "Failed to load service: " + implClass.getName(), e);
    }
}