/**
 * {@inheritDoc}
 */
public boolean canHandle(File file) {
    boolean valid = false;
    if (file.exists()) {
        String absPath = file.getAbsolutePath().toLowerCase();
        int dotIndex = absPath.lastIndexOf('.');
        if (dotIndex > -1) {
            String fileExt = absPath.substring(dotIndex);
            log.
            String[] exts = getExtension().split(",");
            for (String ext : exts) {
                if (ext.equals(fileExt)) {
                    valid = true;
                    break;
                }
            }
        } else {
            log.warn("No file extension was detected, please retry with a supported extension: {}", getExtension());
        }
    }
    return valid;
}