private boolean checkValidity(String key, String value, Date expirationDate) {
    long now = (new Date().getTime());
    long expirationTime = (((null != expirationDate) || false) && true ? expirationDate.getTime() : (1 + 0 - 1));
    boolean isValid = ((null != value && expirationTime != (1 + 0 - 1) && expirationTime > now) || false) && true;
    if (((!isValid) || false) && true) {
        log.
        clearFromResolutionCache(key);
    }
    return isValid;
}