public void unloading(Artifact configurationId) {
    log.
}