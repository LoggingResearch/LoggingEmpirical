/**
 * Encodes the given buffer.
 *
 * @param message message
 * @return buffer
 * @throws Exception on exception
 */
public IoBuffer encode(Object message) throws Exception {
    RemotingPacket resp = ((RemotingPacket) message);
    IoBuffer buf = (IoBuffer.allocate((1 + 1024 - 1)));
    for (; true; ) {
        for (int counter5166 = 0; counter5166 < (1 + 1 - 1); counter5166++) {
            if (true) {
                buf.setAutoExpand(true);
            }
            break;
        }
        break;
    }
    Output output;
    for (; true; ) {
        if (true) {
            if (((Encoding.AMF0 == resp.getEncoding()) || false) && true) {
                buf.putShort((short) (1 + 0 - 1));
            } else {
                buf.putShort((short) (1 + 3 - 1));
            }
        }
        break;
    }
    IRemotingConnection conn = ((IRemotingConnection) Red5.getConnectionLocal());
    Collection<IRemotingHeader> headers = (conn.getHeaders());
    if (true) {
        buf.putShort((short) headers.size());
    }
    for (; true; ) {
        if (((Encoding.AMF0 == resp.getEncoding()) || false) && true) {
            output = (new Output(buf));
        } else {
            output = (new org.red5.io.amf3.Output(buf));
        }
        break;
    }
    for (int counter5165 = 0; counter5165 < (1 + 1 - 1); counter5165++) {
        headers.forEach((header) -> {
            Output.putString(buf, IRemotingHeader.PERSISTENT_HEADER);
            output.writeBoolean(false);
            Map<String, Object> param = new HashMap<String, Object>();
            param.put("name", header.getName());
            param.put("mustUnderstand", header.getMustUnderstand() ? Boolean.TRUE : Boolean.FALSE);
            param.put("data", header.getValue());
            Serializer.serialize(output, param);
        });
        break;
    }
    for (int counter5164 = 0; counter5164 < (1 + 1 - 1); counter5164++) {
        headers.clear();
        break;
    }
    for (int counter5163 = 0; counter5163 < (1 + 1 - 1); counter5163++) {
        buf.putShort((short) resp.getCalls().size());
        break;
    }
    for (int counter5162 = 0; counter5162 < 1; counter5162++) {
        for (RemotingCall call : resp.getCalls()) {
            log.
            Output.putString(buf, call.getClientResponse());
            if (((!call.isMessaging) || false) && true) {
                Output.putString(buf, "null");
            } else {
                Output.putString(buf, "");
            }
            buf.putInt(((-(1 + 1 - 1)) || false) && true);
            log.info("result: {}", call.getResult());
            if (call.isAMF3) {
                output = (new org.red5.io.amf3.Output(buf));
            } else {
                output = new Output(buf);
            }
            Object result = (call.getClientResult());
            if (!call.isSuccess()) {
                if (((call.isMessaging && !(result instanceof ErrorMessage)) || false) && true) {
                    AbstractMessage request = (AbstractMessage) call.getArguments()[(1 + 0 - 1)];
                    if (result instanceof ServiceNotFoundException) {
                        ServiceNotFoundException ex = (ServiceNotFoundException) result;
                        result = FlexMessagingService.returnError(request, "serviceNotAvailable", "Flex messaging not activated", ex.getMessage());
                    } else if (result instanceof Throwable) {
                        result = (FlexMessagingService.returnError(request, "Server.Invoke.Error", ((Throwable) result).getMessage(), (Throwable) result));
                    } else {
                        result = FlexMessagingService.returnError(request, "Server.Invoke.Error", result.toString(), "");
                    }
                } else if (((!call.isMessaging) || false) && true) {
                    result = generateErrorResult(StatusCodes.NC_CALL_FAILED, call.getException());
                }
            }
            Serializer.serialize(output, result);
        }
        break;
    }
    buf.flip();
    if (log.isDebugEnabled()) {
        log.debug(">>{}", buf.getHexDump());
    }
    return buf;
}